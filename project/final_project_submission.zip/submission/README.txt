The structure of this folder is as follows:

submission
|--toy
|   Source code for the toy examples in working with the Python/C API.
|
|--vtr
|   Source code for VTR. Changed files include: 
|       External libraries modified/fixed to support newer version of Ubuntu linux:
|-----------libs/libvtrutil/src/vtr_geometry.h
|-----------libs/libvtrutil/src/vtr_version.cpp.in
|-----------libs/libvtrutil/test/main.cpp
|-----------libs/EXTERNAL
|-----------libs/EXTERNAL/libargparse/src/argparse.hpp
|-----------libs/EXTERNAL/libcatch/catch.hpp
|-----------ODIN_II/SRC/include/Hashtable.hpp            
|       
|       Modifications to vpr to support ML feature extraction and the ML Predictor option:
|-----------vpr/src/base/read_options.cpp
|-----------vpr/src/base/vpr_types.h
|-----------vpr/src/base/ShowSetup.cpp
|-----------vpr/src/base/vpr_context.h
|-----------vpr/src/base/read_options.h
|-----------vpr/src/base/SetupVPR.cpp
|-----------vpr/src/base/vpr_api.cpp
|-----------vpr/src/route/rr_graph.cpp
|-----------vpr/src/route/routing_predictor.cpp
|-----------vpr/src/route/routing_predictor.h
|-----------vpr/src/route/route_common.cpp
|-----------vpr/src/route/route_timing.cpp
|-----------vpr/CMakeLists.txt
|       
|       Titan script download modification
|-----------vtr_flow/scripts/download_titan.py
|
|--ml_predictor
|   Source code for Andrew's FCCM23 paper. All files were changed except for constants.py, misc.py, 
|   data_normalizer.py, and temp.py. The main (novel) code is in train_and_test.py: test(). The other 
|   files were modified/deleted to support single dataset inference (prior code was tailored specifically
|   for training and testing with the simulator).
|
|--logs
|   Results from the report are taken from these logs outputted from VPR. The final run (vpr_des90_og.log) 
|   after all implementation uses the default predictor and is the same as VPR from the original VTR 8.0.0. 
|   The first run (vpr_sparcT1_og_unfiltered.log) shows the original, unfiltered output originally meant to 
|   be input into the ml_predictor as a raw input for processing.
|
|--pdf report (CPEN513 - Final Project Report)
        

---
Usage prerequisites:
- Python3 (with scikit-learn==1.0.1)
- cmake
- make
- g++
- ubuntu22.04