#include <iostream>
#include <python3.10/Python.h>

int main(int argc, char** argv){
    // Set environment is need to determine python path
    setenv("PYTHONPATH", ".", 1);
    // Initialize the Python Interpreter
    Py_Initialize();

    // Set in path to find the custom python module.
    PyObject* sysPath = PySys_GetObject("path");
    PyList_Append(sysPath, PyUnicode_FromString("~/testing"));
    
    // Load the Python module and args
    PyObject *pName = PyUnicode_FromString("toy");
    PyObject *pModule = PyImport_Import(pName);
    PyObject *args = Py_BuildValue("(i)", 15);

    if (pModule != NULL) {
        std::cout << "Python module found\n";

        // Load all module level attributes as a dictionary
        PyObject *pDict = PyModule_GetDict(pModule);
        
        // Note that since the module is loaded as a dictionary, a lookup on pDict would fail as you were trying to find something as an attribute which existed as a key in the dictionary
        PyObject *pFunc = PyDict_GetItem(pDict, PyUnicode_FromString("test"));
        PyObject *value;

        if(pFunc != NULL){
            value = PyObject_CallObject(pFunc, args);
            std::cout << "Output is " << (int)PyLong_AsLong(value) << '\n';
        } else {
            std::cout << "Couldn't find func\n";
        }
    }
    else
        std::cout << "Python Module not found\n";
    return 0;
}