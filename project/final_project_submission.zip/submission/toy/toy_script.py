
print("Hello World!")

def test(value):
    print("This is a test function")
    return value