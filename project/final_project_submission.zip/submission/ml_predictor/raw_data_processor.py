"""
For creating a dataset from VTR logged routing output
"""
import math
import os
import time
from os import path
import re
from constants import Idx, VTR_MAX_ITERS, TITAN_CIRCUIT_NAMES, MCNC_VTR_CIRCUIT_NAMES, VALID_CIRCUIT_NAMES, \
    KOIOS_CIRCUIT_NAMES, TOTHER_CIRCUIT_NAMES
from warnings import warn
from sklearn.linear_model import LinearRegression


def process_vtr_output():
    """
    Process data from all .out files in directory raw_routing_data and organize into a format ready to create datasets
    from.
    All of this processing is to be universal to all prediction tasks. I.e. any task-specific data changes are to be
    done at a later stage of the data pipeline (dataset compilation).
    :return:
    """
    full_start = time.time()
    warning_list = []
    # Get relative path to raw data directory
    base_path = path.dirname(__file__)
    raw_data_dir_path = path.abspath(path.join(base_path, "..", "raw_routing_data"))
    raw_data_dir_path_koi = path.abspath(path.join(base_path, "..", "raw_routing_data", "koios"))
    raw_data_dir_path_ttn = path.abspath(path.join(base_path, "..", "raw_routing_data", "titan"))
    # raw_data_dir_path_to = path.abspath(path.join(base_path, "..", "raw_routing_data", "titan_other"))

    fingerprint_history = []
    write_path_history = []
    duplicate_route_detected = False

    bad_ml_feature_length_files = []

    # Iterate through files in directory
    file_list = os.listdir(raw_data_dir_path) + os.listdir(raw_data_dir_path_koi) + \
                    os.listdir(raw_data_dir_path_ttn) #+ os.listdir(raw_data_dir_path_to)
    file_list.sort()
    for filename in file_list:
        valid_naming_pattern = r'.*?.out'
        # valid_naming_pattern = r'.*_((\d+)|(s\d+))(_((p\d+)|(cw\d+)))?.out'
        if not re.fullmatch(valid_naming_pattern, filename):
            if filename != ".gitignore" and filename != "koios" and filename != "titan" and filename != "titan_other":
                # Should never have a non-matching file in the raw data directory. Alert user and make them
                # interact with program execution.
                input(f"File does not match raw data naming convention, won't process: {filename}")
            # print(f"Skipping no match: {filename}")
            continue
        # circuit_name_extraction_pattern = r'_((\d+)|(s\d+))(_((p\d+)|(cw\d+)))?.out'
        # circuit_name = re.sub(circuit_name_extraction_pattern, '', filename)
        circuit_name = filename[:-4]
        # circuit_name = circuit_name.replace("koi_", '')  # For koios benchmarks
        placer_seed=1
        # placer_seed = re.sub(
        #     r'_.*',
        #     '',
        #     filename.replace("koi_", '').replace(f"{circuit_name}_", '').replace(".out", '')
        # ).replace('s', '')
        # if not placer_seed.isdecimal():
        #     exit(f"ERROR: Bad filename (extraction), placer seed '{placer_seed}' is non-decimal! Filename: {filename}")
        # if circuit_name != "CH_DFSIN":
        #     continue

        # if circuit_name in VALID_CIRCUIT_NAMES:
        #     print(f"Processing {filename}")
        #     process_start = time.time()
        # else:
        #     warning_list.append(
        #         f"Skipping {filename} with circuit name '{circuit_name}'"
        #     )
        #     warn(f"Skipping {filename} with circuit name '{circuit_name}'")
        #     continue

        # Create read/write file paths
        if "koi_" in filename:
            target_read_path = path.abspath(
                path.join(raw_data_dir_path_koi, filename)
            )
        elif circuit_name in TITAN_CIRCUIT_NAMES:
            target_read_path = path.abspath(
                path.join(raw_data_dir_path_ttn, filename)
            )
        elif circuit_name in TOTHER_CIRCUIT_NAMES:
            target_read_path = path.abspath(
                path.join(raw_data_dir_path_to, filename)
            )
        else:
            target_read_path = path.abspath(
                path.join(raw_data_dir_path, filename)
            )
        target_write_path = path.abspath(
            path.join(base_path, "..", "processed_routing_data", f"{circuit_name}_{placer_seed}_data.csv")
        )
        if target_write_path in write_path_history:
            edit_mode = 'at'
        else:
            edit_mode = 'wt'
        
        # print(f'target read path: {target_read_path}')
        # print(f'target write path: {target_write_path}')

        channel_width_results, new_warnings = check_channel_width_results(target_read_path, return_warns=True)
        # print(f'channel width results: {channel_width_results}')
        warning_list = warning_list + new_warnings

        # Determine which FPGA architecture the circuit was routed on
        if circuit_name in TITAN_CIRCUIT_NAMES or circuit_name in TOTHER_CIRCUIT_NAMES:
            is_k6_arch = 0
            is_titan_arch = 1
        else:
            is_k6_arch = 1
            is_titan_arch = 0

        with open(target_write_path, edit_mode) as outfile:
            if 'w' in edit_mode:  # Only write the header the first time the file is written to
                # Header with column labels
                for idx, item in enumerate(Idx):
                    outfile.write(f"{item.name}")
                    if idx != len(Idx) - 1:
                        outfile.write(",")
                outfile.write('\n')

            with open(target_read_path, 'rt') as infile:
                routing_fingerprint = None
                current_attempt_is_duplicate = False
                node_count_total = 0
                for line_idx, line in enumerate(infile):
                    if "RR Graph Nodes" in line:
                        # Get number of routing resource graph nodes
                        # Need this to calculate metrics later on
                        tokens = line.split(' ')
                        node_count_total = int(tokens[-1].strip())
                    if "ml_features" in line:
                        line = line.replace("ml_features:", '')
                        #line = raw_data_full_cap_mean_sb_cong_typo_fix(line)  # TODO: Remove this when raw data fixed
                        tokens = line.split(',')

                        if len(tokens) != 89:
                            bad_ml_feature_length_files.append(target_read_path)
                            # print('________________________ERROR_________________________')
                            # print(f'length of tokens is {len(tokens)}')
                            # print(tokens)
                            # print('_________________________________________________')

                        # Do not process data at or beyond the maximum desired iteration
                        # We do not process the max iter itself because there is no prediction task at this point
                        # Since we know the circuit to be unroutable
                        current_iter = int(tokens[Idx.CURR_ITER.value])
                        if current_iter >= VTR_MAX_ITERS:
                            continue

                        # Get the result for the routing attempt this line corresponds with
                        # Ignore the data if the attempt never finished (i.e. unknown if circuit routed or not)
                        channel_width = tokens[Idx.CHAN_WIDTH.value]
                        # print(f'channel width: {channel_width}')
                        routing_attempt_result = int(channel_width_results[channel_width])
                        # print(f'routing attempt result: {routing_attempt_result}')
                        # if routing_attempt_result == -1:
                        #     # Routing data is invalid. Probably a timeout during min chan width search.
                        #     warning_list.append(
                        #         f"Invalid routing data in {target_read_path} channel width {channel_width}"
                        #     )
                        #     warn(f"Invalid routing data in {target_read_path} channel width {channel_width}")
                            # continue
                        # if 0 < routing_attempt_result == current_iter:
                        #     # Routing attempt yields a legal solution within VTR_MAX_ITERS
                        #     # Do not include data from the last iteration as there is no
                        #     # prediction task on this iteration
                        #     continue
                        # if routing_attempt_result < -1 and current_iter == -1 * routing_attempt_result:
                        #     # Routing attempt yields no legal solution but was not run up to VTR_MAX_ITERS
                        #     # Do not include data from the last iteration as we would not even know
                        #     # the true value for a prediction on this iteration
                        #     # (The next iteration could be legal or illegal, we don't know)
                        #     continue

                        # Ensure no duplicate routing attempts exist between files
                        # This should find any/all duplicates, unless somehow there are two adjacent duplicate attempts
                        # in the same file
                        if routing_fingerprint is None:
                            routing_fingerprint = get_route_fingerprint_from_line(line, processed_data=False)
                            # Check if this fingerprint has already been seen
                            if routing_fingerprint in fingerprint_history:
                                current_attempt_is_duplicate = True
                                duplicate_route_detected = True
                                print(f"Duplicate routing attempt fingerprint: {routing_fingerprint}")
                            else:
                                current_attempt_is_duplicate = False
                                fingerprint_history.append(routing_fingerprint)
                            # Initialize linear regressor for measuring VTR prediction linearity fit
                            reg = LinearRegression()
                            route_attempt_iter_hist = []
                            route_attempt_log_overuse_hist = []
                        else:
                            # Check for a routing attempt change
                            current_line_fingerprint = get_route_fingerprint_from_line(line, processed_data=False)
                            for i in range(len(routing_fingerprint)):
                                if routing_fingerprint[i] != current_line_fingerprint[i]:
                                    # New routing attempt, check if its fingerprint has already been seen
                                    if current_line_fingerprint in fingerprint_history:
                                        current_attempt_is_duplicate = True
                                        duplicate_route_detected = True
                                        print(f"Duplicate routing attempt fingerprint: {current_line_fingerprint}")
                                    else:
                                        current_attempt_is_duplicate = False
                                    routing_fingerprint = current_line_fingerprint
                                    fingerprint_history.append(routing_fingerprint)
                                    # Reset iteration/overuse history for new routing attempt
                                    route_attempt_iter_hist = []
                                    route_attempt_log_overuse_hist = []

                        if current_attempt_is_duplicate:
                            # Don't process duplicate data
                            warning_list.append(
                                f"WARNING: Skipping duplicate attempt data: {target_read_path}"
                            )
                            warn(f"WARNING: Skipping duplicate attempt data: {target_read_path}")
                            continue

                        # Add iteration and log of overuse to history
                        light_overuse_fraction = float(tokens[Idx.LIGHT_OVER_FRAC.value])
                        heavy_overuse_fraction = float(tokens[Idx.HEAVY_OVER_FRAC.value])
                        current_overuse_count = int(
                            (light_overuse_fraction + heavy_overuse_fraction) * node_count_total
                        )
                        if current_overuse_count == 0:
                            log_current_overuse = 0
                        else:
                            log_current_overuse = math.log(current_overuse_count)
                        route_attempt_iter_hist.append([current_iter])
                        route_attempt_log_overuse_hist.append(log_current_overuse)

                        # Calculate linearity of VTR prediction window
                        # VTR uses the more recent half of all iterations, excluding the current iteration
                        # Presumably the current iteration exclusion is a bug/oversight
                        vtr_pred_linearity = -1
                        if len(route_attempt_iter_hist)-1 < 9:
                            # VTR only makes a prediction if there are at least 9 iterations in the history
                            vtr_pred_linearity = 0
                        else:
                            # Fit to data
                            vtr_iter_hist = []
                            vtr_log_overuse_hist = []
                            hist_length = len(route_attempt_iter_hist)-1
                            start_idx = hist_length - round(0.5*hist_length)
                            for i in range(start_idx, hist_length):
                                vtr_iter_hist.append(route_attempt_iter_hist[i])
                                vtr_log_overuse_hist.append(route_attempt_log_overuse_hist[i])
                            reg.fit(X=vtr_iter_hist, y=vtr_log_overuse_hist)
                            vtr_pred_linearity = reg.score(X=vtr_iter_hist, y=vtr_log_overuse_hist)

                        # Calculate overall routing attempt linearity
                        route_attempt_linearity = -1
                        if len(route_attempt_iter_hist) < 3:
                            # Can't regress on 0 or 1 point. Insensible to regress on 2 points (always perfect).
                            route_attempt_linearity = 0
                        else:
                            reg.fit(X=route_attempt_iter_hist, y=route_attempt_log_overuse_hist)
                            route_attempt_linearity = reg.score(
                                X=route_attempt_iter_hist, y=route_attempt_log_overuse_hist
                            )

                        if routing_attempt_result > 0:
                            true_final_iter = routing_attempt_result
                        elif routing_attempt_result < -1:
                            true_final_iter = -1 * routing_attempt_result
                        else:
                            # exit(f"ERROR: Encountered a bad routing attempt result while processing {target_read_path}:"
                            #      f" {routing_attempt_result}")
                            true_final_iter = -1 * routing_attempt_result

                        line_data = line.strip()
                        data_tokens = line_data.split(',')
                        # Fix bugged features
                        # bottom 50% mean fanout
                        b50p_mean_fanout = float(data_tokens[Idx.B50P_MEAN_FAN.value])
                        b50p_mean_fanout /= 10
                        data_tokens[Idx.B50P_MEAN_FAN.value] = str(b50p_mean_fanout)
                        # circuit name
                        corrected_circuit_name = data_tokens[Idx.CIRC_NAME.value]
                        corrected_circuit_name = corrected_circuit_name.replace("_stratixiv_arch_timing", "")
                        data_tokens[Idx.CIRC_NAME.value] = corrected_circuit_name
                        # Convert VTR's prediction to an integer if it is a floating point value
                        vtr_pred_original = data_tokens[Idx.VTR_ITER_PRED].strip()
                        # print(f'original prediction is : {vtr_pred_original}')
                        if vtr_pred_original != "N/A" and vtr_pred_original != "inf":
                            if vtr_pred_original not in line:
                                exit(line_idx)
                            vtr_pred_new = str(int(round(float(vtr_pred_original))))
                            data_tokens[Idx.VTR_ITER_PRED.value] = vtr_pred_new
                        line_data = ','.join(data_tokens)
                        # print(current_iter)
                        # print(true_final_iter)
                        # if current_iter > true_final_iter or current_iter >= VTR_MAX_ITERS:
                        #     exit(f"ERROR: Encountered an iteration at or beyond the expected maximum possible!"
                        #          f"Iteration {current_iter}, expected final iteration {true_final_iter} and VTR MAX "
                        #          f"{VTR_MAX_ITERS}")
                        outfile.write(line_data + f",{is_k6_arch},{is_titan_arch},{routing_attempt_result}," +
                                                  f"{vtr_pred_linearity},{route_attempt_linearity}\n")
                        if target_write_path not in write_path_history:
                            # We have confirmed a write to the output file
                            # Subsequent data write from different input files should now know to
                            # append to the output file
                            write_path_history.append(target_write_path)
        process_end = time.time()
        # print(f"Processing took {int(process_end-process_start)}s")
    if duplicate_route_detected:
        warning_list.append(
            "At least one duplicate routing attempt was detected. Check above logs for more info."
        )
        warn("At least one duplicate routing attempt was detected. Check above logs for more info.")
    if len(bad_ml_feature_length_files) != 0:
        warning_list.append(
            "WARNING: Files that don't have 89 features:"
        )
        warn("WARNING: Files that don't have 89 features:")
        bad_ml_feature_length_files.sort()
        for bad_filename in bad_ml_feature_length_files:
            warning_list.append(
                bad_filename
            )
            warn(bad_filename)
    full_end = time.time()
    for warning in warning_list:
        warn(warning)
    print(f"Total processing time: {int(full_end-full_start)}s")


def validate_processed_data():
    """
    For validating each processed VTR routing data file
    :return:
    """
    # Get relative path to raw data directory
    base_path = path.dirname(__file__)
    data_dir_path = path.abspath(path.join(base_path, "..", "processed_routing_data"))

    # Iterate through files in directory
    for filename in sorted(os.listdir(data_dir_path)):
        if filename == ".gitignore":
            continue
        circuit_name = re.sub(r'_\d_data.csv', '', filename)
        placer_seed = filename.split('_')[-2]
        if circuit_name in VALID_CIRCUIT_NAMES and re.search(r'_\d_data.csv', filename) and placer_seed.isdecimal():
            print(f"Validating {filename}")
            # File path for testing
            read_path = path.abspath(path.join(data_dir_path, filename))

            with open(read_path, 'rt') as infile:
                last_line = ""
                searching_for_final_iter = False
                expected_final_iter = -1

                for line_idx, line in enumerate(infile):
                    if line_idx == 0:
                        continue
                    if line_idx % 10000 == 0:
                        print(line_idx)

                    validate_processed_data_line(line)

                    # Validate that the routing iteration number always increments by 1 (unless new routing attempt)
                    # Also validate that the true final iteration number has not changed (unless new routing attempt)
                    tokens = line.split(",")
                    current_iter = int(tokens[Idx.CURR_ITER.value])
                    if current_iter != 1:
                        last_tokens = last_line.split(',')
                        last_iter = int(last_tokens[Idx.CURR_ITER.value])
                        assert current_iter == last_iter+1, \
                            f"Iteration counting mismatch! {last_iter} -> {current_iter}"
                        current_true_final_iter = tokens[Idx.TRUE_ITER.value].strip()
                        last_true_final_iter = last_tokens[Idx.TRUE_ITER.value].strip()
                        assert current_true_final_iter == last_true_final_iter, \
                            f"{current_true_final_iter} == {last_true_final_iter}"

                    # Validate that the last iteration in an attempt is 1 less than the "true" value for completion
                    # Assuming that the corresponding routing attempt was successful
                    # Otherwise last iter should be VTR_MAX_ITERS-1
                    # (We don't keep the final iteration as there is nothing to predict)
                    true_final_iter = int(tokens[Idx.TRUE_ITER.value].strip())
                    if not searching_for_final_iter:
                        searching_for_final_iter = True
                        if true_final_iter == 0:  # 0 means the route failed
                            # We expect to encounter the routing of VTR_MAX_ITER-1 eventually
                            exit("ERROR: deprecated routing result nomenclature")
                        elif abs(true_final_iter) > VTR_MAX_ITERS:
                            expected_final_iter = VTR_MAX_ITERS - 1
                        elif true_final_iter > 0:
                            expected_final_iter = true_final_iter - 1
                        elif true_final_iter < -1:
                            expected_final_iter = (-1 * true_final_iter) - 1
                        else:
                            exit("ERROR: true_final_iter is -1 (an error code, invalid routing)")
                    else:
                        if current_iter == expected_final_iter:
                            searching_for_final_iter = False
                        # If the routing iteration decrements that means there is an error in the data
                        # This is because there shouldn't be a decrement before finding the final iteration
                        last_tokens = last_line.split(',')
                        last_iter = int(last_tokens[Idx.CURR_ITER.value])
                        # The following assert seems redundant, but it covers the case where current_iter == 1
                        # This code block should not run on current_iter == 1, so if the below fails then
                        # we missed the final iter in validating the previous routing attempts' data.
                        assert current_iter == last_iter + 1, \
                            f"Did not find the final iteration of a routing attempt! Current iter: {current_iter}, " \
                            f"Last iter: {last_iter}, line index: {line_idx}"
                    last_line = line
                assert not searching_for_final_iter, \
                    "Did not find the final iteration of a routing attempt at end of file!"
        else:
            print(f"Skipping {filename}")


def validate_processed_data_line(line):
    """
    Validate one datapoint/row from VTR processed data.
    :param line:
    :return:
    """
    tokens = line.split(',')
    #print(tokens)
    assert len(tokens) == 94, str(len(tokens))  # 94 = 89 + 5 (for the addition of the true routing result and
    # vtr prediction linearity and route attempt linearity and architecture one-hot-encoding)

    current_iter = tokens[Idx.CURR_ITER.value]
    assert current_iter.isdecimal(), current_iter
    assert int(current_iter) < VTR_MAX_ITERS, current_iter
    circuit_name = tokens[Idx.CIRC_NAME.value]
    assert circuit_name in VALID_CIRCUIT_NAMES, circuit_name
    placer_seed = tokens[Idx.PLACE_SEED.value]
    assert placer_seed.isdecimal(), placer_seed
    grid_width = tokens[Idx.GRID_WIDTH.value]
    assert grid_width.isdecimal(), grid_width
    grid_height = tokens[Idx.GRID_HEIGHT.value]
    assert grid_height.isdecimal(), grid_height
    channel_width = tokens[Idx.CHAN_WIDTH.value]
    assert channel_width.isdecimal(), channel_width
    total_overuse_norm = float(tokens[Idx.TOT_OVER_NORM.value])
    assert total_overuse_norm >= 0.0, total_overuse_norm
    light_overuse_fraction = float(tokens[Idx.LIGHT_OVER_FRAC.value])
    assert 0.0 <= light_overuse_fraction <= 1.0, f"0.0 <= light_overuse_fraction <= 1.0"
    heavy_overuse_fraction = float(tokens[Idx.HEAVY_OVER_FRAC.value])
    assert 0.0 <= heavy_overuse_fraction <= 1.0, f"0.0 <= heavy_overuse_fraction <= 1.0"
    assert light_overuse_fraction + heavy_overuse_fraction <= 1.0, \
        f"{light_overuse_fraction} + {heavy_overuse_fraction} <= 1.0"
    mean_node_overuse = float(tokens[Idx.MEAN_OVER.value])
    assert mean_node_overuse >= 1.0, str(mean_node_overuse)
    stdev_node_overuse = float(tokens[Idx.STD_OVER.value])
    assert stdev_node_overuse >= 0.0, str(stdev_node_overuse)
    top5p_mean_overuse = float(tokens[Idx.T5P_MEAN_OVER.value])
    assert top5p_mean_overuse >= 0.0, str(top5p_mean_overuse)
    if top5p_mean_overuse != 0:
        # When <20 nodes are overused, the top5% mean overuse will be 0
        assert top5p_mean_overuse >= mean_node_overuse, f"{top5p_mean_overuse} >= {mean_node_overuse}"
    bottom50p_mean_overuse = float(tokens[Idx.B50P_MEAN_OVER.value])
    assert bottom50p_mean_overuse >= 0.0, str(bottom50p_mean_overuse)
    assert bottom50p_mean_overuse <= mean_node_overuse
    max_overuse = tokens[Idx.MAX_OVER.value]
    assert max_overuse.isdecimal(), max_overuse
    max_overuse = int(max_overuse)
    assert max_overuse >= mean_node_overuse, f"{max_overuse} >= {mean_node_overuse}"
    assert max_overuse >= top5p_mean_overuse
    min_overuse = tokens[Idx.MIN_OVER.value]
    assert min_overuse.isdecimal(), min_overuse
    assert int(min_overuse) <= mean_node_overuse, f"{min_overuse} <= {mean_node_overuse}"
    if bottom50p_mean_overuse != 0:
        # Need to have enough overused nodes to assert below
        assert int(min_overuse) <= bottom50p_mean_overuse
    total_underuse_norm = float(tokens[Idx.TOT_UNDER_NORM.value])
    assert total_underuse_norm >= 0.0, str(total_underuse_norm)
    light_underuse_fraction = float(tokens[Idx.LIGHT_UNDER_FRAC.value])
    assert 0.0 <= light_underuse_fraction <= 1.0, f"0.0 <= light_underuse_fraction <= 1.0"
    heavy_underuse_fraction = float(tokens[Idx.HEAVY_UNDER_FRAC.value])
    assert 0.0 <= heavy_underuse_fraction <= 1.0, f"0.0 <= heavy_underuse_fraction <= 1.0"
    assert light_underuse_fraction + heavy_underuse_fraction <= 1.0, \
        f"{light_underuse_fraction} + {heavy_underuse_fraction} <= 1.0"
    mean_underuse = float(tokens[Idx.MEAN_UNDER.value])
    assert mean_underuse >= 1.0, str(mean_underuse)
    stdev_underuse = float(tokens[Idx.STD_UNDER.value])
    assert stdev_underuse >= 0.0, str(stdev_underuse)
    top5p_mean_underuse = float(tokens[Idx.T5P_MEAN_UNDER.value])
    assert top5p_mean_underuse >= 0.0, str(top5p_mean_underuse)
    assert top5p_mean_underuse >= mean_underuse
    bottom5p_mean_underuse = float(tokens[Idx.B5P_MEAN_UNDER.value])
    assert bottom5p_mean_underuse >= 0.0, str(bottom5p_mean_underuse)
    assert bottom5p_mean_underuse <= mean_underuse
    max_underuse = tokens[Idx.MAX_UNDER.value]
    assert max_underuse.isdecimal(), max_underuse
    assert int(max_underuse) >= mean_underuse, f"{max_underuse} >= {mean_underuse}"
    assert int(max_underuse) >= top5p_mean_underuse
    min_underuse = tokens[Idx.MIN_UNDER.value]
    assert min_underuse.isdecimal(), min_underuse
    assert int(min_underuse) <= mean_underuse, f"{min_underuse} <= {mean_underuse}"
    assert int(min_underuse) <= bottom5p_mean_underuse
    full_capacity_frac = float(tokens[Idx.FULL_CAP_COUNT.value])
    assert 0.0 <= full_capacity_frac <= 1.0, f"0.0 <= {full_capacity_frac} <= 1.0"
    # mean_sink_underuse_frac = float(tokens[Idx.MEAN_SINK_UNDER.value])
    # assert mean_sink_underuse_frac >= 0.0, f"{mean_sink_underuse_frac} >= 0.0"
    mean_sb_cong = float(tokens[Idx.MEAN_SB_CONG.value])
    assert mean_sb_cong >= 0.0, str(mean_sb_cong)
    stdev_sb_cong = float(tokens[Idx.STD_SB_CONG.value])
    assert stdev_sb_cong >= 0.0, str(stdev_sb_cong)
    max_sb_cong = float(tokens[Idx.MAX_SB_CONG.value])
    assert max_sb_cong >= mean_sb_cong, f"{max_sb_cong} >= {mean_sb_cong}"
    min_sb_cong = float(tokens[Idx.MIN_SB_CONG.value])
    assert min_sb_cong >= 0.0, str(min_sb_cong)
    assert min_sb_cong <= mean_sb_cong, f"{min_sb_cong} <= {mean_sb_cong}"
    top5p_mean_sb_cong = float(tokens[Idx.T5P_MEAN_SB_CONG.value])
    assert top5p_mean_sb_cong >= mean_sb_cong, f"{top5p_mean_sb_cong} >= {mean_sb_cong}"
    # floating point leniency for next assert
    assert top5p_mean_sb_cong <= max_sb_cong+0.000001, f"{top5p_mean_sb_cong} <= {max_sb_cong}"
    bottom5p_mean_sb_cong = float(tokens[Idx.B5P_MEAN_SB_CONG.value])
    assert bottom5p_mean_sb_cong <= mean_sb_cong, f"{bottom5p_mean_sb_cong} <= {mean_sb_cong}"
    assert bottom5p_mean_sb_cong >= min_sb_cong, f"{bottom5p_mean_sb_cong} >= {min_sb_cong}"
    low_cong_sb_frac = float(tokens[Idx.LOW_SB_FRAC.value])
    assert 0.0 <= low_cong_sb_frac <= 1.0, f"0.0 <= {low_cong_sb_frac} <= 1.0"
    high_cong_sb_frac = float(tokens[Idx.HIGH_SB_FRAC.value])
    assert 0.0 <= high_cong_sb_frac <= 1.0, f"0.0 <= {high_cong_sb_frac} <= 1.0"
    light_over_sb_frac = float(tokens[Idx.LIGHT_OVER_SB_FRAC.value])
    assert 0.0 <= light_over_sb_frac <= 1.0, f"0.0 <= {light_over_sb_frac} <= 1.0"
    heavy_over_sb_frac = float(tokens[Idx.HEAVY_OVER_SB_FRAC.value])
    assert 0.0 <= heavy_over_sb_frac <= 1.0, f"0.0 <= {heavy_over_sb_frac} <= 1.0"
    assert 0.99999 <= low_cong_sb_frac + high_cong_sb_frac + light_over_sb_frac + heavy_over_sb_frac <= 1.00001, \
        f"0.99999 <= {low_cong_sb_frac + high_cong_sb_frac + light_over_sb_frac + heavy_over_sb_frac} <= 1.00001,"
    mean_wlpa = float(tokens[Idx.MEAN_WLPA.value])
    assert mean_wlpa >= 0.0, str(mean_wlpa)
    stdev_wlpa = float(tokens[Idx.STD_WLPA.value])
    assert stdev_wlpa >= 0.0, str(stdev_wlpa)
    top5p_mean_wlpa = float(tokens[Idx.T5P_MEAN_WLPA.value])
    assert top5p_mean_wlpa >= mean_wlpa, f"{top5p_mean_wlpa} >= {mean_wlpa}"
    bottom5p_mean_wlpa = float(tokens[Idx.B5P_MEAN_WLPA.value])
    assert bottom5p_mean_wlpa <= mean_wlpa, f"{bottom5p_mean_wlpa} <= {mean_wlpa}"
    assert bottom5p_mean_wlpa >= 0.0, str(bottom5p_mean_wlpa)
    max_wlpa = float(tokens[Idx.MAX_WLPA.value])
    assert max_wlpa >= top5p_mean_wlpa, f"{max_wlpa} >= {top5p_mean_wlpa}"
    min_wlpa = float(tokens[Idx.MIN_WLPA.value])
    assert min_wlpa <= bottom5p_mean_wlpa, f"{min_wlpa} <= {bottom5p_mean_wlpa}"
    assert min_wlpa >= 0.0, str(min_wlpa)
    mean_wlpt = float(tokens[Idx.MEAN_WLPT.value])
    assert mean_wlpt >= 0.0, str(mean_wlpt)
    stdev_wlpt = float(tokens[Idx.STD_WLPT.value])
    assert stdev_wlpt >= 0.0, str(stdev_wlpt)
    top5p_mean_wlpt = float(tokens[Idx.T5P_MEAN_WLPT.value])
    assert top5p_mean_wlpt >= mean_wlpt, f"{top5p_mean_wlpt} >= {mean_wlpt}"
    bottom5p_mean_wlpt = float(tokens[Idx.B5P_MEAN_WLPT.value])
    assert bottom5p_mean_wlpt <= mean_wlpt, f"{bottom5p_mean_wlpt} <= {mean_wlpt}"
    assert bottom5p_mean_wlpt >= 0.0, str(bottom5p_mean_wlpt)
    max_wlpt = float(tokens[Idx.MAX_WLPT.value])
    assert max_wlpt >= top5p_mean_wlpt, f"{max_wlpt} >= {top5p_mean_wlpt}"
    min_wlpt = float(tokens[Idx.MIN_WLPT.value])
    assert min_wlpt <= bottom5p_mean_wlpt, f"{min_wlpt} <= {bottom5p_mean_wlpt}"
    assert min_wlpt >= 0.0, str(min_wlpt)
    valid_net_count_norm = float(tokens[Idx.VALID_NET_COUNT_NORM.value])
    assert valid_net_count_norm >= 0.0, f"{valid_net_count_norm} >= 0.0"
    if valid_net_count_norm > 1.0:
        warn(f"WARNING: valid net count normalized == {valid_net_count_norm} > 1.0")
    num_sinks_norm = float(tokens[Idx.NUM_SINKS_NORM.value])
    assert 0.0 <= num_sinks_norm <= 1.0, f"0.0 <= {num_sinks_norm} <= 1.0"
    low_fanout_net_frac = float(tokens[Idx.LOW_FAN_FRAC.value])
    assert 0.0 <= low_fanout_net_frac <= 1.0, f"0.0 <= {low_fanout_net_frac} <= 1.0"
    med_fanout_net_frac = float(tokens[Idx.MED_FAN_FRAC.value])
    assert 0.0 <= med_fanout_net_frac <= 1.0, f"0.0 <= {med_fanout_net_frac} <= 1.0"
    high_fanout_net_frac = float(tokens[Idx.HIGH_FAN_FRAC.value])
    assert 0.0 <= high_fanout_net_frac <= 1.0, f"0.0 <= {high_fanout_net_frac} <= 1.0"
    assert 0.999999 <= low_fanout_net_frac + med_fanout_net_frac + high_fanout_net_frac <= 1.000001, \
        f" 0.999999 < {low_fanout_net_frac + med_fanout_net_frac + high_fanout_net_frac} <= 1.000001"
    min_fanout = float(tokens[Idx.MIN_FAN.value])
    assert min_fanout >= 1.0, f"{min_fanout} >= 1.0"
    bottom50p_mean_fanout = float(tokens[Idx.B50P_MEAN_FAN])
    assert bottom50p_mean_fanout >= min_fanout, f"{bottom50p_mean_fanout} >= {min_fanout}"
    mean_fanout = float(tokens[Idx.MEAN_FAN.value])
    assert mean_fanout >= bottom50p_mean_fanout, f"{mean_fanout} >= {bottom50p_mean_fanout}"
    top5p_mean_fanout = float(tokens[Idx.MEAN_FAN.value])
    assert top5p_mean_fanout >= mean_fanout, f"{top5p_mean_fanout} >= {mean_fanout}"
    max_fanout = float(tokens[Idx.MAX_FAN.value])
    assert max_fanout >= top5p_mean_fanout, f"{max_fanout} >= {top5p_mean_fanout}"
    stdev_fanout = float(tokens[Idx.STDEV_FAN.value])
    assert stdev_fanout >= 0.0, f"{stdev_fanout} >= 0.0"
    ncpr_00_norm = float(tokens[Idx.NCPR_00.value])
    assert ncpr_00_norm >= 0.0, f"{ncpr_00_norm} >= 0.0"
    ncpr_01_norm = float(tokens[Idx.NCPR_01.value])
    assert ncpr_01_norm >= 0.0, f"{ncpr_01_norm} >= 0.0"
    ncpr_02_norm = float(tokens[Idx.NCPR_02.value])
    assert ncpr_02_norm >= 0.0, f"{ncpr_02_norm} >= 0.0"
    ncpr_10_norm = float(tokens[Idx.NCPR_10.value])
    assert ncpr_10_norm >= 0.0, f"{ncpr_10_norm} >= 0.0"
    ncpr_11_norm = float(tokens[Idx.NCPR_11.value])
    assert ncpr_11_norm >= 0.0, f"{ncpr_11_norm} >= 0.0"
    ncpr_12_norm = float(tokens[Idx.NCPR_12.value])
    assert ncpr_12_norm >= 0.0, f"{ncpr_12_norm} >= 0.0"
    ncpr_20_norm = float(tokens[Idx.NCPR_20.value])
    assert ncpr_20_norm >= 0.0, f"{ncpr_20_norm} >= 0.0"
    ncpr_21_norm = float(tokens[Idx.NCPR_21.value])
    assert ncpr_21_norm >= 0.0, f"{ncpr_21_norm} >= 0.0"
    ncpr_22_norm = float(tokens[Idx.NCPR_22.value])
    assert ncpr_22_norm >= 0.0, f"{ncpr_22_norm} >= 0.0"
    nets_per_resource = float(tokens[Idx.NET_PER_RES.value])
    assert nets_per_resource >= 0.0, f"{nets_per_resource} >= 0.0"
    if nets_per_resource >= 1.0:
        warn(f"WARNING: nets per resource == {nets_per_resource} >= 1.0")
    sinks_per_resource = float(tokens[Idx.SINK_PER_RES.value])
    if sinks_per_resource >= 1.0:
        warn(f"WARNING: sinks per resource == {sinks_per_resource} >= 1.0")
    assert sinks_per_resource >= 0.0, f"{sinks_per_resource} >= 0.0"
    wirelength_ratio = float(tokens[Idx.WL_RTIO.value])
    assert 0.0 <= wirelength_ratio, str(wirelength_ratio)
    if int(current_iter) == 1:
        assert wirelength_ratio <= 1.0, f"First routing iteration has wirelength ratio {wirelength_ratio}"
    vtr_iteration_prediction = tokens[Idx.VTR_ITER_PRED.value]
    assert vtr_iteration_prediction.isdecimal() or vtr_iteration_prediction == "N/A" or \
           vtr_iteration_prediction == "inf", vtr_iteration_prediction
    present_overuse_factor = float(tokens[Idx.PRES_FAC.value])
    assert present_overuse_factor >= 0.0, f"{present_overuse_factor} >= 0.0"
    total_bb_update_norm = float(tokens[Idx.TOT_BB_UP_NORM.value])
    assert total_bb_update_norm >= 0.0, f"{total_bb_update_norm} >= 0.0"
    iter_bb_update_norm = float(tokens[Idx.ITER_BB_UP_NORM.value])
    assert 0.0 <= iter_bb_update_norm <= total_bb_update_norm, f"0.0 <={iter_bb_update_norm} <= {total_bb_update_norm}"
    total_connections_routed_norm = float(tokens[Idx.TOT_CONN_ROUTE_NORM.value])
    assert total_connections_routed_norm >= 0.0, f"{total_connections_routed_norm} >= 0.0"
    iter_connections_routed_norm = float(tokens[Idx.ITER_CONN_ROUTE_NORM.value])
    assert 0.0 <= iter_connections_routed_norm <= total_connections_routed_norm, \
        f"0.0 <= {iter_connections_routed_norm} <= {total_connections_routed_norm}"
    total_nets_routed_norm = float(tokens[Idx.TOT_NET_ROUTE_NORM.value])
    assert total_nets_routed_norm >= 0.0, f"{total_nets_routed_norm} >= 0.0"
    iter_nets_routed_norm = float(tokens[Idx.ITER_NET_ROUTE_NORM.value])
    assert 0.0 <= iter_nets_routed_norm <= total_nets_routed_norm, \
        f"0.0 <= {iter_nets_routed_norm} <= {total_nets_routed_norm}"
    total_heap_push_norm = float(tokens[Idx.TOT_HEAP_PUSH_NORM.value])
    assert total_heap_push_norm >= 0.0, f"{total_heap_push_norm} >= 0.0"
    iter_heap_push_norm = float(tokens[Idx.ITER_HEAP_PUSH_NORM.value])
    assert 0.0 <= iter_heap_push_norm <= total_heap_push_norm, f"0.0 <= {iter_heap_push_norm} <= {total_heap_push_norm}"
    total_heap_pop_norm = float(tokens[Idx.TOT_HEAP_POP_NORM.value])
    assert 0.0 <= total_heap_pop_norm <= total_heap_push_norm, f"0.0 <= {total_heap_pop_norm} <= {total_heap_push_norm}"
    iter_heap_pop_norm = float(tokens[Idx.ITER_HEAP_POP_NORM.value])
    assert 0.0 <= iter_heap_pop_norm <= total_heap_pop_norm, f"0.0 <= {iter_heap_pop_norm} <= {total_heap_pop_norm}"
    overuse_time = float(tokens[Idx.OVER_TIME.value])
    assert overuse_time >= 0.0, f"{overuse_time} >= 0.0"
    switchbox_time = float(tokens[Idx.SB_TIME.value])
    assert switchbox_time >= overuse_time, f"{switchbox_time} >= {overuse_time}"
    wlpa_time = float(tokens[Idx.WLPA_TIME.value])
    assert wlpa_time >= switchbox_time, f"{wlpa_time} >= {switchbox_time}"
    ncpr_time = float(tokens[Idx.NCPR_TIME.value])
    assert ncpr_time >= wlpa_time, f"{ncpr_time} >= {wlpa_time}"
    ml_time = float(tokens[Idx.ML_TIME.value])
    assert ml_time >= ncpr_time, f"{ml_time} >= {ncpr_time}"
    iter_time = float(tokens[Idx.ITER_TIME.value])
    assert iter_time >= ml_time, f"{iter_time} >= {ml_time}"
    total_time = float(tokens[Idx.TOT_TIME.value])
    assert total_time >= iter_time, f"{total_time} >= {iter_time}"
    is_k6_arch = int(tokens[Idx.IS_K6.value])
    is_ttn_arch = int(tokens[Idx.IS_TTN.value])
    if is_k6_arch == 0 and is_ttn_arch == 1:
        pass
    elif is_k6_arch == 1 and is_ttn_arch == 0:
        pass
    else:
        exit(f"ERROR: is_k6 == {is_k6_arch}, is_ttn == {is_ttn_arch}")
    true_final_iteration_count = tokens[Idx.TRUE_ITER.value].strip()
    assert abs(int(true_final_iteration_count)), f"{true_final_iteration_count}"
    if true_final_iteration_count != "0":
        assert abs(int(true_final_iteration_count)) > int(current_iter), \
            f"abs({true_final_iteration_count}) > {current_iter}"
    vtr_pred_linearity = float(tokens[Idx.VTR_PRED_LIN.value].strip())
    assert vtr_pred_linearity <= 1.0, f"VTR prediction linearity >1.0: {vtr_pred_linearity}"
    route_linearity = float(tokens[Idx.ROUTE_LIN.value].strip())
    assert route_linearity <= 1.0, f"Routing attempt linearity >1.0: {route_linearity}"


def check_channel_width_results(target_read_path, verbose=False, return_warns=False):
    """
    For checking the results of routing attempt at various channel widths for a given circuit
    :param verbose:
    :param target_read_path:
    :return:
    """
    warning_list = []
    # print(f'target read path: {target_read_path}')
    with open(target_read_path, 'rt') as infile:
        channel_width_results = {}
        channel_width = "-1"
        routing_attempt_result = "-1"
        found_current_result = False
        iters_spent_routing = 0
        num_route_attempts_in_file = 0  # How many routing attempts were performed and output to the target file?
        # If a search was performed, multiple attempts may happen or a single channel width with a single attempt
        # could have been performed. This is important when a timeout happens. If there were multiple attempts,
        # the ongoing attempt during timeout *could* have been successfully routed and so we call it invalid.
        # If there was only one attempt, then a timeout indicates the circuit was unroutable.

        # Check what channel widths were attempted during routing and what their results were
        for line in infile:
            if "ml_features" in line:
                if channel_width == "-1":
                    num_route_attempts_in_file += 1
                tokens = line.split(',')
                iters_spent_routing = tokens[Idx.CURR_ITER.value].replace("ml_features:", "")
                channel_width = tokens[Idx.CHAN_WIDTH.value]
                # print(f'channel width is {channel_width}')
            if "TIME LIMIT" in line and num_route_attempts_in_file > 1:
                if found_current_result:
                    exit("ERROR: Identified routing result twice")
                routing_attempt_result = "-1"  # This routing attempt was not completed due to Slurm time limit
                found_current_result = True
            if "Successfully routed after" in line:
                if found_current_result:
                    exit("ERROR: Identified routing result twice")
                tokens = line.split(' ')
                routing_attempt_result = tokens[3]  # Will be the number of iterations required to route successfully
                found_current_result = True
            if "Routing failed" in line or ("TIME LIMIT" in line and num_route_attempts_in_file == 1):
                if found_current_result:
                    exit("ERROR: Identified routing result twice")
                # Because routing attempts were done at a variety of iteration maximums and time limits,
                # denote a routing attempt that never found a legal solution as having a result equal to
                # the negative of the number of iterations spent routing.
                # This allows for consistency and easier error-checking in data handling.
                routing_attempt_result = str(-1 * int(iters_spent_routing))
                if int(iters_spent_routing) < VTR_MAX_ITERS and "TIME LIMIT" not in line:
                    warning_list.append(
                        f"ERROR: Processing a file which was run with iter limit < currently selected iter limit!: {target_read_path}"
                    )
                    warn(f"ERROR: Processing a file which was run with iter limit < currently selected iter limit!: {target_read_path}")
                found_current_result = True

            if found_current_result:
                channel_width_results[channel_width] = routing_attempt_result
                # Reset search
                channel_width = "-1"
                routing_attempt_result = "-1"
                found_current_result = False
                iters_spent_routing = 0

    if num_route_attempts_in_file < 1:
        warning_list.append(
            f"This file has no routing attempts!: {target_read_path}"
        )
        warn(f"This file has no routing attempts!: {target_read_path}")
    if channel_width != "-1":  # This routing attempt came from a file that was still in progress of being written
        # warning_list.append(
        #     f"This file ({target_read_path}) may be incomplete! Check Slurm for complete version!"
        # )
        # warn(f"This file ({target_read_path}) may be incomplete! Check Slurm for complete version!")
        channel_width_results[channel_width] = "-1"
    if verbose:
        print(channel_width_results)
    if return_warns:
        return channel_width_results, warning_list
    else:
        return channel_width_results


def get_route_fingerprint_from_line(line: str, processed_data=True):
    fingerprint_indices = [
        Idx.CIRC_NAME.value,
        Idx.PLACE_SEED.value,
        Idx.GRID_WIDTH.value,
        Idx.GRID_HEIGHT.value,
        Idx.CHAN_WIDTH.value
    ]
    if processed_data:
        fingerprint_indices.append(Idx.TRUE_ITER.value)
    tokens = line.split(',')
    routing_fingerprint_list = []
    for i in fingerprint_indices:
        routing_fingerprint_list.append(tokens[i].strip())
    routing_fingerprint = tuple(routing_fingerprint_list)
    return routing_fingerprint


if __name__ == "__main__":
    process_vtr_output()
    # validate_processed_data()


