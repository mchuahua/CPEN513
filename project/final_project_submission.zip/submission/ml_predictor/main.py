"""
Top-level script
"""
import argparse
from os import path
from typing import Optional
from warnings import warn

import sklearn.feature_selection

import train_and_test
from train_and_test import CustomEstimator, CustomClassifier, CustomRegressor, MonolithicSystem, PartitionSystem
import raw_data_processor
import dataset_compiler
import sys
from constants import VTR_MAX_ITERS, KOIOS_CIRCUIT_NAMES, TITAN_CIRCUIT_NAMES, VALID_CIRCUIT_NAMES, Idx, IdxPost
import time
import data_generator
import pickle
import data_normalizer


def detect_statics():
    X_train, y_train = data_generator.get_dataset(
        is_classification=True,
        target_prefix="mvto",
        get_train_data=True,
        get_test_data=False
    )
    X_train_trimmed, sel = data_generator.remove_static_features(
        X_train=X_train,
        verbose=True
    )
    print(X_train.shape)
    print(X_train_trimmed.shape)
    mask = sel.get_support(indices=False)
    indices = sel.get_support(indices=True)
    print(indices)
    print(mask)
    for idx, is_included in enumerate(mask):
        if not is_included:
            print(list(IdxPost)[idx])


def compile_sim_data():
    dataset_compiler.create_all_sim_data()


def compile_train_data(
        is_classification,
        train_prefix,
        dataset_max_iters,
        min_iters,
):
    if compile_train_data:
        print("Compiling training dataset")
        compile_start = time.time()
        dataset_compiler.compile_dataset(
            is_classification=is_classification,
            included_circuit_names=VALID_CIRCUIT_NAMES,
            excluded_circuit_names=TITAN_CIRCUIT_NAMES+KOIOS_CIRCUIT_NAMES,
            outfile_name_prefix=train_prefix,
            compile_train=True,
            compile_test=False,
            test_data_max_iters=dataset_max_iters,
            test_data_min_iters=min_iters,
            train_data_max_iters=dataset_max_iters,
            train_data_min_iters=min_iters
        )
        compile_end = time.time()
        print(f"Train data compilation took {int(compile_end - compile_start)}s")
        print(f"Validating training data")
        valid_start = time.time()
        is_dataset_valid, _ = dataset_compiler.validate_compiled_dataset(
            is_classification=is_classification,
            target_prefix=train_prefix
        )
        if not is_dataset_valid:
            exit("ERROR: Invalid training data!")
        valid_end = time.time()
        print(f"Training data validation took {int(valid_end - valid_start)}s")
        # Normalize compiled data and save scaler
        print("Getting training data")
        X_train, y_train = data_generator.get_dataset(
            is_classification=is_classification,
            target_prefix=train_prefix,
            get_train_data=True,
            get_test_data=False
        )
        # Normalize training data
        print("Normalizing training data")
        normal_start = time.time()
        X_train_unnormalized = X_train.copy()
        X_train, scaler = data_normalizer.normalize_feature_data(X_train=X_train)
        normal_end = time.time()
        print(f"Normalizing took {int(normal_end - normal_start)}s")
        base_path = path.dirname(__file__)
        if is_classification:
            target_type = "class"
        else:
            target_type = "reg"
        scaler_path = path.abspath(
            path.join(
                base_path, "..", "scalers", f"{train_prefix}_{target_type}_ss.pkl"
            )
        )
        with open(scaler_path, 'wb') as outfile:
            pickle.dump(scaler, outfile)


def test(
        is_classification,
        test_prefix,
        train_prefix="mvto",
        dataset_max_iters=VTR_MAX_ITERS,
        test_min_iters=1,
        target_model_name="",
        is_loocv=False,
        use_tuned_models=False,
        test_on_train_data=False
):
    # Load models
    target_models: list[CustomEstimator] = []
    if target_model_name == "":
        # Load all models
        if is_classification:
            model_names = [
                "sgd_class",
                "rf_class",
                "erf_class",
                "adab_class",
                "gradb_class",
                "hgb_class",
            ]
        else:
            model_names = [
                "omp_reg",
                "bag_reg",
                "adab_reg",
                "rf_reg",
                "erf_reg",
                "gradb_reg",
                "hgb_reg"
            ]
        if use_tuned_models:
            for idx, name in enumerate(model_names):
                model_names[idx] = f"{name}_tuned"
        for model_name in model_names:
            if is_classification:
                target_models.append(
                    CustomClassifier(
                        name=model_name,
                        estimator=data_generator.load_trained_model(
                            is_classification=is_classification,
                            train_prefix=train_prefix,
                            model_name=model_name)
                    )
                )
            else:
                target_models.append(
                    CustomRegressor(
                        name=model_name,
                        estimator=data_generator.load_trained_model(
                            is_classification=is_classification,
                            train_prefix=train_prefix,
                            model_name=model_name)
                    )
                )
    # Load data if testing on training data
    if test_on_train_data:
        if "mvto" not in test_prefix:
            warn(f"WARNING: Potentially bad test_prefix {test_prefix} for testing on train data")
        X_train, y_train = data_generator.get_dataset(
            is_classification=is_classification,
            target_prefix=test_prefix,
            get_train_data=True,
            get_test_data=False
        )
        scaler = data_generator.get_scaler(
            is_classification=is_classification,
            train_prefix=train_prefix
        )
        X_train_unnormalized = X_train.copy()
        X_train, _ = data_normalizer.normalize_feature_data(X_test=X_train, scaler=scaler)
    else:
        X_train, y_train, X_train_unnormalized = None, None, None
    train_and_test.test_models(
        target_models=target_models,
        is_classification=is_classification,
        train_prefix=train_prefix,
        test_prefix=test_prefix,
        dataset_max_iters=dataset_max_iters,
        test_min_iters=test_min_iters,
        is_loocv=is_loocv,
        test_on_train_data=test_on_train_data,
        X_train=X_train,
        y_train=y_train,
        X_train_unnormalized=X_train_unnormalized
    )

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--type', type=str, default="", required=False)
    parser.add_argument('--model_name', type=str, default="", required=False)
    parser.add_argument('--dataset_max_iters', type=int, default=VTR_MAX_ITERS, required=False)
    parser.add_argument('--dataset_min_iters', type=int, default=1, required=False)
    parser.add_argument('--test_min_iters', type=int, default=1, required=False)
    parser.add_argument('--train_prefix', type=str, default="mvto", required=False)
    parser.add_argument('--window_min', type=int, default=1, required=False)
    parser.add_argument('--window_max', type=int, default=1, required=False)
    parser.add_argument('--sim_class_thresh', type=int, default=VTR_MAX_ITERS, required=False)
    parser.add_argument('--partition_count', type=int, default=1, required=False)
    parser.add_argument('--compile_train_data', action='store_true', required=False)
    parser.add_argument('--detect_statics', action='store_true', required=False)
    parser.add_argument('--train', action='store_true', required=False)
    parser.add_argument('--test', action='store_true', required=False)
    parser.add_argument('--test_on_train', action='store_true', required=False)
    parser.add_argument('--compile_sim', action='store_true', required=False)
    parser.add_argument('--sim', action='store_true', required=False)
    parser.add_argument('--sim_partition', action='store_true', required=False)
    parser.add_argument('--sim_vtr', action='store_true', required=False)
    parser.add_argument('--tune', action='store_true', required=False)
    parser.add_argument('--loo_cv', action='store_true', required=False)
    parser.add_argument('--use_tuned', action='store_true', required=False)
    args = parser.parse_args()

    if args.loo_cv and args.test_on_train:
        exit("ERROR: Do not use --test_on_train with --loo_cv")

    is_target_classification = None
    if args.test or args.train or args.compile_train_data or args.tune or args.test_on_train:
        if args.type == "reg":
            is_target_classification = False
        elif args.type == "class":
            is_target_classification = True
        else:
            exit("ERROR: Bad type supplied")

    if args.compile_train_data:
        compile_train_data(
            is_classification=is_target_classification,
            train_prefix=f"mvto-{args.dataset_max_iters}-{args.dataset_min_iters}",
            dataset_max_iters=args.dataset_max_iters,
            min_iters=args.dataset_min_iters
        )

    if args.detect_statics:
        detect_statics()

    if args.train:
        pass

    if args.test or args.test_on_train:
        test_prefix = f"ttnkoi-{args.dataset_max_iters}-{args.dataset_min_iters}"
        if args.use_tuned:
            test_prefix = test_prefix + "-tuned"
        test(
            is_classification=is_target_classification,
            test_prefix=test_prefix,
            train_prefix=args.train_prefix,
            dataset_max_iters=args.dataset_max_iters,
            test_min_iters=args.dataset_min_iters,
            use_tuned_models=args.use_tuned,
            is_loocv=args.loo_cv,
            test_on_train_data=args.test_on_train
        )

    if args.tune:
        pass

    if args.compile_sim:
        compile_sim_data()

    if args.sim or (args.sim_partition and args.partition_count == 0):
        pass

    if args.sim_partition and args.partition_count > 0:
        pass

    if args.sim_vtr:
        pass
