"""
For training and testing ML models
"""
import copy
import time
from typing import Optional, Union
import joblib
import sklearn.base
import random
import data_normalizer
import dataset_compiler
import data_generator
from sklearn.metrics import confusion_matrix, classification_report, mean_absolute_error, r2_score, max_error, \
    explained_variance_score, median_absolute_error, mean_absolute_percentage_error, mean_squared_error
import os
import predictors
from sklearn import neighbors, neural_network, linear_model, svm, gaussian_process, naive_bayes, tree, ensemble, \
    kernel_ridge, cross_decomposition
from os import path
from raw_data_processor import VALID_CIRCUIT_NAMES
from constants import VTR_MAX_ITERS, IdxPost, KOIOS_CIRCUIT_NAMES, TITAN_CIRCUIT_NAMES, SIM_LIST, \
    MCNC_VTR_CIRCUIT_NAMES, TOTHER_CIRCUIT_NAMES, VTR_CIRCUIT_NAMES
from warnings import warn
from abc import ABC, abstractmethod
from raw_data_processor import *

class CustomEstimator:
    name: str = ""
    estimator: Optional[sklearn.base.BaseEstimator] = None
    is_regressor: bool = True

    def __init__(self,
                 name: str,
                 estimator: Optional[sklearn.base.BaseEstimator],
                 is_regressor: bool):
        self.name = name
        self.estimator = estimator
        self.is_regressor = is_regressor

class CustomClassifier(CustomEstimator):
    def __init__(self, name: str, estimator: Optional[sklearn.base.BaseEstimator]):
        super().__init__(name, estimator, is_regressor=False)


class CustomRegressor(CustomEstimator):
    def __init__(self, name: str, estimator: Optional[sklearn.base.BaseEstimator]):
        super().__init__(name, estimator, is_regressor=True)

def test(actual_iteration):
   
    # Remove all compiled and processed files in folders
    main_path = "/home/linux/route_prediction_ml-main"
    paths = [main_path + '/compiled_routing_data/', main_path + '/processed_routing_data/']
    for path in paths:
        for file_name in os.listdir(path):
            if file_name.endswith(".csv"):
                os.remove(path + '/' + file_name)

    # Process raw data
    process_vtr_output()

    # Compile raw data into classification
    dataset_compiler.compile_dataset(
                    is_classification=True,
                    compile_train=False,
                    compile_test=True,
                    test_data_max_iters=VTR_MAX_ITERS,
                    test_data_min_iters=1
                )

    # Read in classification dataset
    X_test_classification, y_test_classification = data_generator.get_dataset(
                is_classification=True,
                target_prefix='',
                get_train_data=False,
                get_test_data=True
            )
    # print('Compiling raw data into regression')
    # Compile raw data into regression
    dataset_compiler.compile_dataset(
                    is_classification=False,
                    compile_train=False,
                    compile_test=True,
                    test_data_max_iters=VTR_MAX_ITERS,
                    test_data_min_iters=1
                )
    # print('Reading in regression dataset')
    
    # Read in regression dataset
    X_test_regression, y_test_regression = data_generator.get_dataset(
                is_classification=False,
                target_prefix='',
                get_train_data=False,
                get_test_data=True
            )
    # print('reading in scalars for classfication')
    # Read in scalars for classfication dataste
    sc150 = data_generator.get_scaler(
        is_classification=True,
        train_prefix='mvto-150-1'
    )
    sc250 = data_generator.get_scaler(
        is_classification=True,
        train_prefix='mvto-250-1'
    )
    sc400 = data_generator.get_scaler(
        is_classification=True,
        train_prefix='mvto-400-1'
    )
    sc1000= data_generator.get_scaler(
        is_classification=True,
        train_prefix='mvto-1000-1'
    )
    # Read in scalars for regression dataset
    sr1000= data_generator.get_scaler(
        is_classification=False,
        train_prefix='mvto-1000-1'
    )
    sr400= data_generator.get_scaler(
        is_classification=False,
        train_prefix='mvto-400-1'
    )
    sr250= data_generator.get_scaler(
        is_classification=False,
        train_prefix='mvto-250-1'
    )
    sr150= data_generator.get_scaler(
        is_classification=False,
        train_prefix='mvto-150-1'
    )
    # print('normailxing data using scalars')

    # Normalize data using scalars
    # print(X_test_classification.reshape(1, -1))
    X_test_classification_150c, _ = data_normalizer.normalize_feature_data(X_test=X_test_classification.reshape(1, -1), scaler=sc150)
    X_test_regression_150r, _ = data_normalizer.normalize_feature_data(X_test=X_test_regression.reshape(1, -1), scaler=sr150)
    X_test_classification_250c, _ = data_normalizer.normalize_feature_data(X_test=X_test_classification.reshape(1, -1), scaler=sc250)
    X_test_regression_250r, _ = data_normalizer.normalize_feature_data(X_test=X_test_regression.reshape(1, -1), scaler=sr250)
    X_test_classification_400c, _ = data_normalizer.normalize_feature_data(X_test=X_test_classification.reshape(1, -1), scaler=sc400)
    X_test_regression_400r, _ = data_normalizer.normalize_feature_data(X_test=X_test_regression.reshape(1, -1), scaler=sr400)
    X_test_classification_1000c, _ = data_normalizer.normalize_feature_data(X_test=X_test_classification.reshape(1, -1), scaler=sc1000)
    X_test_regression_1000r, _ = data_normalizer.normalize_feature_data(X_test=X_test_regression.reshape(1, -1), scaler=sr1000)

    # print('loading models')

# Load classification models
    mc150 = CustomClassifier(
                        name='mvto-150-1_erf_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=True,
                            train_prefix='mvto-150-1',
                            model_name="erf_class_bal")
                    ).estimator
    mc250 = CustomClassifier(
                        name='mvto-250-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=True,
                            train_prefix='mvto-250-1',
                            model_name="gradb_class_bal")
                    ).estimator
    mc400 = CustomClassifier(
                        name='mvto-400-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=True,
                            train_prefix='mvto-400-1',
                            model_name="gradb_class_bal")
                    ).estimator
    mc1000 = CustomClassifier(
                        name='mvto-1000-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=True,
                            train_prefix='mvto-1000-1',
                            model_name="gradb_class_bal")
                    ).estimator
# Load regression models
    mr150 = CustomClassifier(
                        name='mvto-150-1_erf_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=False,
                            train_prefix='mvto-150-1',
                            model_name="hgb_reg_tuned")
                    ).estimator
    mr250 = CustomClassifier(
                        name='mvto-250-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=False,
                            train_prefix='mvto-250-1',
                            model_name="gradb_reg_tuned")
                    ).estimator
    mr400 = CustomClassifier(
                        name='mvto-400-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=False,
                            train_prefix='mvto-400-1',
                            model_name="gradb_reg")
                    ).estimator
    mr1000 = CustomClassifier(
                        name='mvto-1000-1_gradb_class_bal',
                        estimator=data_generator.load_trained_model(
                            is_classification=False,
                            train_prefix='mvto-1000-1',
                            model_name="gradb_reg")
                    ).estimator
    # print('evaluating classification models')

    # Throw compiled data into classifier models to get prediction for 0-150, 151-250, 251-400, 400-1000.
    f150 = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_classification_150c, y_test=y_test_classification, y_pred=None,
                        model=mc150,
                        labels=[0, 1],
                        max_iter=150,
                        min_iter=1,
                        time_inference=False
                    )
    # print(f'f150 is {f150}')
    f250 = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_classification_250c, y_test=y_test_classification, y_pred=None,
                        model=mc250,
                        labels=[0, 1],
                        max_iter=250,
                        min_iter=1,
                        time_inference=False
                    )
    # print(f'f250 is {f250}')
    f400 = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_classification_400c, y_test=y_test_classification, y_pred=None,
                        model=mc400,
                        labels=[0, 1],
                        max_iter=400,
                        min_iter=1,
                        time_inference=False
                    )
    # print(f'f400 is {f400}')
    f1000 = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_classification_1000c, y_test=y_test_classification, y_pred=None,
                        model=mc1000,
                        labels=[0, 1],
                        max_iter=1000,
                        min_iter=1,
                        time_inference=False
                    )
    # print(f'f1000 is {f1000}')
    
    # Get the prediction
    f150 = f150[-1]
    f250 = f250[-1]
    f400 = f400[-1]
    f1000 = f1000[-1]

    # Depending on iteration, we do regression on the particular model 
    if actual_iteration < 150 and f150 == 1:
        # Throw into r150
        pred = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_regression_150r, y_test=y_test_regression, y_pred=None,X_test_unnormalized=X_test_regression,
                        model=mr150,
                        labels=[0, 1],
                        max_iter=150,
                        min_iter=1,
                        time_inference=False
                    )
        # print('150')
    elif actual_iteration < 250 and f250 == 1:
        # Throw into r250
        pred = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_regression_250r, y_test=y_test_regression, y_pred=None,X_test_unnormalized=X_test_regression,
                        model=mr250,
                        labels=[0, 1],
                        max_iter=250,
                        min_iter=1,
                        time_inference=False
                    )
        # print('250')
    elif actual_iteration < 400 and f400 == 1:
        # Throw into r400
        pred = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_regression_400r, y_test=y_test_regression, y_pred=None,X_test_unnormalized=X_test_regression,
                        model=mr400,
                        labels=[0, 1],
                        max_iter=400,
                        min_iter=1,
                        time_inference=False
                    )
    elif actual_iteration < 1000 and f1000 == 1:
        # Throw into r1000
        pred = predictors.evaluate_model(
                        is_classification=True,
                        X_test=X_test_regression_1000r, y_test=y_test_regression, y_pred=None, X_test_unnormalized=X_test_regression,
                        model=mr1000,
                        labels=[0, 1],
                        max_iter=1000,
                        min_iter=1,
                        time_inference=False
                    )
    else:
        pred = -1

    try: 
        if pred[0] > 0:
            pred = pred[-1]
    except:
        pass
    return pred



# if __name__ == "__main__":
# #     # arraylist = []
# #     # for i in range(50):
# #     #     asdf = test(i)
# #     #     arraylist.append(asdf)
    
    
# #     # print(f'prediction: {arraylist}')
#     asdf = test(15)
#     print(f'prediction: {asdf}')