import math
from typing import Optional

from sklearn.metrics import confusion_matrix, classification_report, mean_absolute_error, \
    mean_absolute_percentage_error, explained_variance_score, max_error, r2_score, \
    median_absolute_error, mean_squared_error
from time import time
import numpy as np
from constants import Idx
import random
from constants import VTR_MAX_ITERS, IdxPost
from warnings import warn


def predict_all(X_train, y_train, X_test, y_test, classifiers):
    for clf in classifiers:
        try:
            start = time()
            print(clf)
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            print(confusion_matrix(y_true=y_test, y_pred=y_pred))
            # ConfusionMatrixDisplay.from_predictions(y_true=y_test, y_pred=y_pred)
            print(classification_report(y_true=y_test, y_pred=y_pred))
            end = time()
            print(str(end - start))
        except ValueError as e:
            print(e)
            continue


def clip_predictions_reg(X, y, max_iter=10000, min_iter=1):
    """
    Clips predictions 'y' based on the maximum prediction value and the current iteration of each prediction
    as informed by 'X'.
    Also clips minimum prediction to be at least 1 (can't predict a circuit will route in the past)
    :param min_iter:
    :param X:
    :param y:
    :param max_iter:
    :return:
    """
    for pred_idx, pred in enumerate(y):
        features = X[pred_idx]
        current_iter = features[IdxPost.CURR_ITER.value]
        pred_absolute = current_iter + pred
        if pred_absolute > max_iter:
            pred = max_iter - current_iter
        elif pred_absolute < min_iter:
            pred = min_iter - current_iter
        if pred < 1:
            pred = 1
        y[pred_idx] = pred
    return y


def predict_random_reg(X, max_iter=10000, min_iter=1):
    """
    Acts as a naive regressor that always predicts the number of iterations remaining
    as a random value out of the set of possible values. Possibilities determined by the
    current iteration in the feature data and the maximum number of iterations.
    :param min_iter:
    :param X:
    :param max_iter:
    :return:
    """
    y_pred = []
    for row in X:
        current_iter = row[IdxPost.CURR_ITER.value]
        pred_max = max_iter - current_iter
        if min_iter > current_iter:
            pred_min = min_iter - current_iter
        else:
            pred_min = 1
        row_pred = random.randint(pred_min, pred_max)
        y_pred.append(row_pred)
    return y_pred


def predict_midpoint_reg(X, max_iter=10000, min_iter=1):
    """
    Naive regressor that always predicts the midpoint between the current iteration
    and the maximum possible number of iterations.
    OR predicts midpoint between a minimum value and the max possible number of iterations iff
    current iteration < specified minimum.
    :param min_iter:
    :param max_iter:
    :param X:
    :return:
    """
    y_pred = []
    for row in X:
        current_iter = row[IdxPost.CURR_ITER.value]
        pred_max = max_iter - current_iter
        if min_iter > current_iter:
            pred_min = min_iter - current_iter
        else:
            pred_min = 1
        row_pred = int(round((pred_max + pred_min)/2.0))
        y_pred.append(row_pred)
    return y_pred


def predict_max_reg(X, max_iter=10000, min_iter=1):
    """
    Naive regressor that always predicts the maximum possible number of iterations remaining.
    :param min_iter:
    :param X:
    :param max_iter:
    :return:
    """
    y_pred = []
    for row in X:
        current_iter = row[IdxPost.CURR_ITER.value]
        iters_remaining = max_iter - current_iter
        y_pred.append(iters_remaining)
    return y_pred


def predict_min_reg(X, max_iter=10000, min_iter=1):
    """
    Naive regressor that always predicts success on the next iteration
    :param min_iter:
    :param max_iter: Not used but included for the sake of interface consistency with other
    naive estimation functions
    :param X:
    :return:
    """
    y_pred = []
    for row in X:
        current_iter = row[IdxPost.CURR_ITER.value]
        if min_iter > current_iter:
            row_pred = min_iter - current_iter
        else:
            row_pred = 1
        y_pred.append(row_pred)
    return y_pred


def evaluate_model(
        is_classification=False,
        X_test=None, y_test=None,
        model=None, y_pred=None, X_test_unnormalized: Optional[np.ndarray] = None,
        labels=None,
        max_iter=VTR_MAX_ITERS,
        min_iter=1,
        time_inference=False
):
    if y_test is None:
        exit("ERROR: Must supply y_test")
    try:
        if y_pred is None:
            if model is None:
                exit("ERROR: Must supply a model or a set of predictions to evaluate")
            if X_test is None:
                exit("ERROR: Must supply X_test or a set of predictions to evaluate")
            if time_inference:
                inference_start = time()
            y_pred = model.predict(X_test)
            if time_inference:
                inference_end = time()
                inference_full = inference_end-inference_start
                print(f"Inference took {inference_full}s on {len(X_test)} inference, " +
                      f"{float(inference_full)/float(len(X_test))} time/inference")
        if not is_classification:
            # Regression
            if X_test_unnormalized is not None:
                y_pred = clip_predictions_reg(
                    X=X_test_unnormalized, y=y_pred,
                    max_iter=max_iter, min_iter=min_iter)
            return y_pred
        else:
            # Classification
            return y_pred
    except ValueError as e:
        print("Error in train_and_evaluate_reg()")
        print(e)
