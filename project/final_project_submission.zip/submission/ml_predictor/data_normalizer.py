"""
For normalizing feature data to zero mean and unit variance
"""
import sklearn
from sklearn import preprocessing
import numpy as np
from warnings import warn


def normalize_feature_data(X_train=None, X_test=None, scaler=None):
    if X_train is None and X_test is None:
        warn(f"X_train and X_test supplied are both None")
    if scaler is None:
        if X_train is None:
            exit("ERROR: Must supply X_train if no pre-trained scaler supplied")
        ss = preprocessing.StandardScaler()
        ss.fit(X_train)
    else:
        ss = scaler

    if X_train is not None:
        X_train_scaled = ss.transform(X_train)
    else:
        X_train_scaled = None

    if X_test is not None:
        X_test_scaled = ss.transform(X_test)
    else:
        X_test_scaled = None

    if X_train is None:
        return X_test_scaled, ss
    elif X_test is None:
        return X_train_scaled, ss
    else:
        return X_train_scaled, X_test_scaled, ss
