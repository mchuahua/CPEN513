"""
Generates datasets from CSV files
"""
import pickle

import joblib
import numpy as np
from os import path
import dataset_compiler
from sklearn.feature_selection import VarianceThreshold, mutual_info_regression, f_regression, r_regression
from data_normalizer import normalize_feature_data
from warnings import warn
from constants import VTR_MAX_ITERS


def remove_static_features(X_train=None, X_test=None, selector=None, verbose=True):
    """
    Perform an analysis on how much each feature varies. I.e. Find static features.
    :return:
    """
    if X_train is None and X_test is None:
        warn(f"X_train and X_test supplied are both None")
    if selector is None:
        if X_train is None:
            exit("ERROR: Must supply X_train if no pre-trained selector supplied")
        sel = VarianceThreshold(threshold=0.0)
        sel = sel.fit(X=X_train)
    else:
        sel = selector
    if X_train is not None:
        original_feature_count = X_train.shape[1]
        X_train_trimmed = sel.transform(X_train)
        new_feature_count = X_train_trimmed.shape[1]
        if verbose:
            print(f"Removed {original_feature_count - new_feature_count} static features")
    else:
        X_train_trimmed = None
    if X_test is not None:
        original_feature_count = X_test.shape[1]
        X_test_trimmed = sel.transform(X_test)
        new_feature_count = X_test_trimmed.shape[1]
        if verbose:
            print(f"Removed {original_feature_count - new_feature_count} static features")
    else:
        X_test_trimmed = None

    if X_train is None:
        return X_test_trimmed, sel
    elif X_test is None:
        return X_train_trimmed, sel
    else:
        return X_train_trimmed, X_test_trimmed, sel


def determine_static_features(X_train):
    sel = VarianceThreshold(threshold=0.0)
    sel = sel.fit(X=X_train)
    original_feature_count = X_train.shape[1]
    X_train_trimmed = sel.transform(X_train)
    new_feature_count = X_train_trimmed.shape[1]
    print(f"Removed {original_feature_count - new_feature_count} static features")


def remove_low_correlation_features(prefix=""):
    """
    Analyze correlations between features and the target variable.
    :param prefix:
    :return:
    """
    target_read_dir = "compiled_routing_data/regression"
    prefix = "featcorr"
    X_train, y_train = get_dataset(
        is_classification=False,
        target_prefix=prefix,
        get_train_data=True,
        get_test_data=False
    )
    mi = mutual_info_regression(
        X=X_train,
        y=y_train,
        discrete_features=False,
        random_state=0
    )
    print("Mutual Information")
    print(mi)
    pearsons_r = r_regression(
        X=X_train,
        y=y_train,
        center=True  # TODO: Should this be True or False?
    )
    print("Pearson's R correlations")
    print(pearsons_r)
    f_test, p_vals = f_regression(
        X=X_train,
        y=y_train,
        center=True  # TODO: Should this be True or False?
    )
    print("F-statistics")
    print(f_test)
    print("P-values")
    print(p_vals)


def load_trained_model(
        is_classification: bool,
        train_prefix: str,
        model_name: str,
        is_balanced=False,
):
    base_path = path.dirname(__file__)
    trained_models_dir = path.abspath(
        path.join(
            base_path, "..", "trained_models",
        )
    )
    if is_classification and is_balanced:
        saved_model_name = f"{train_prefix}_{model_name}_bal"
    else:
        saved_model_name = f"{train_prefix}_{model_name}"
    saved_model_path = path.abspath(
        path.join(
            trained_models_dir, saved_model_name
        )
    )
    # print(f"Loading {saved_model_name}")
    return joblib.load(saved_model_path)


def get_full_dataset_reg(target_prefix=""):
    if target_prefix == "":
        exit("ERROR: Must supply a prefix to get_full_dataset_reg()!")
    # print("Getting regression dataset")
    return get_dataset(
        is_classification=False,
        target_prefix=target_prefix
    )


def get_full_dataset_class(target_prefix=""):
    if target_prefix == "":
        exit("ERROR: Must supply a prefix to get_full_dataset_class()!")
    return get_dataset(
        is_classification=True,
        target_prefix=target_prefix
    )


def get_dataset(
        generic_read_dir="compiled_routing_data",
        is_classification=False,
        target_prefix="",
        get_train_data=True,
        get_test_data=True,
        get_sim_data=False,
        sim_file_name_base=""
):
    if get_sim_data and sim_file_name_base == "":
        warn("WARNING: Trying to get blank simulation dataset!")
    # Get path to data directory
    base_path = path.dirname(__file__)
    if not get_sim_data:
        if is_classification:
            target_dir = "classification"
        else:
            target_dir = "regression"
        data_path = path.abspath(
            path.join(
                base_path, "..", generic_read_dir, target_dir
            )
        )
    else:
        data_path = path.abspath(
            path.join(
                base_path, "..", "routing_sim_data"
            )
        )

    def get_xy(is_train=True):
        if get_sim_data:
            feature_data_path = path.abspath(
                path.join(
                    data_path, f"{sim_file_name_base}_X.csv"
                )
            )
            label_data_path = path.abspath(
                path.join(
                    data_path, f"{sim_file_name_base}_y.csv"
                )
            )
            time_data_path = path.abspath(
                path.join(
                    data_path, f"{sim_file_name_base}_time.csv"
                )
            )
            time_data = np.genfromtxt(time_data_path, delimiter=',', dtype=float)
        else:
            if is_train:
                dataset_type = "train"
            else:
                dataset_type = "test"
                
            feature_data_path = path.abspath(
                path.join(
                    data_path, f"{target_prefix}_{dataset_type}_X.csv"
                )
            )
            label_data_path = path.abspath(
                path.join(
                    data_path, f"{target_prefix}_{dataset_type}_y.csv"
                )
            )

            time_data = None
        X = np.genfromtxt(feature_data_path, delimiter=',', dtype=float)
        y = np.genfromtxt(label_data_path, delimiter=',', dtype=int)
        # print(X, y)
        if len(X) == 0 or len(y) == 0:
            if get_sim_data:
                return [], [], []
            return [], []
        # print(get_sim_data)
        if get_sim_data:
            if len(time_data) == 0:
                return [], [], []
        y = y[0]  # Get just the true labels, ignore the VTR predictions
        if get_sim_data:
            return X, y, time_data
        else:
            # print(X, y)
            return X, y

    # Training data
    if get_train_data:
        X_train, y_train = get_xy(is_train=True)
    else:
        X_train, y_train = None, None
    # Testing data
    if get_test_data:
        if get_sim_data:
            X_test, y_test, time_test = get_xy(is_train=False)
        else:
            X_test, y_test = get_xy(is_train=False)
            time_test = None
    else:
        X_test, y_test, time_test = None, None, None


    if get_train_data and get_test_data:
        return X_train, y_train, X_test, y_test
    elif get_train_data:
        return X_train, y_train
    elif get_test_data:
        if get_sim_data:
            return X_test, y_test, time_test
        else:
            return X_test, y_test
    else:
        return None


def get_scaler(
        is_classification,
        train_prefix
):
    base_path = path.dirname(__file__)
    if is_classification:
        target_type = "class"
    else:
        target_type = "reg"
    scaler_path = path.abspath(
        path.join(
            base_path, "..", "scalers", f"{train_prefix}_{target_type}_ss.pkl"
        )
    )
    with open(scaler_path, 'rb') as infile:
        scaler = pickle.load(infile)
    return scaler


def get_vtr_test_predictions(
        is_classification=False, prefix="", test_on_train_data=False,
        get_sim_data=False, sim_file_name_base=""
):
    if get_sim_data and sim_file_name_base == "":
        warn("WARNING: Trying to get blank VTR simulation dataset!")
    if prefix == "" and not get_sim_data:
        exit("ERROR: Must supply prefix to get_vtr_test_predictions()!")
    # Get path to data directory
    base_path = path.dirname(__file__)

    if not get_sim_data:
        if is_classification:
            subdir = "classification"
        else:
            subdir = "regression"
        if test_on_train_data:
            dataset_type = "train"
        else:
            dataset_type = "test"
        label_data_path = path.abspath(
            path.join(
                base_path, "..", f"compiled_routing_data/{subdir}", f"{prefix}_{dataset_type}_y.csv"
            )
        )
    else:
        label_data_path = path.abspath(
            path.join(
                base_path, "..", "routing_sim_data", f"{sim_file_name_base}_y.csv"
            )
        )
    y = np.genfromtxt(label_data_path, delimiter=',', dtype=int)
    if len(y) == 0:
        y_test_vtr = []
    else:
        y_test_vtr = y[:, 1]
    return y_test_vtr


if __name__ == "__main__":
    #remove_static_features(prefix="featvar")
    X_test, y_test = get_dataset(
                is_classification=False,
                target_prefix='',
                get_train_data=False,
                get_test_data=True
            )
    print(X_test)
    print('asdf')
    print(y_test)
