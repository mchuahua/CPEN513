"""
For functions of temporary utility
"""
import os
import numpy as np
import data_generator
from os import path
from constants import Idx, IdxPost
import train_and_test
from train_and_test import calculate_class_metrics
from sklearn import neighbors, neural_network, linear_model, svm, gaussian_process, naive_bayes, tree, ensemble, \
    kernel_ridge, cross_decomposition
import pandas as pd
import data_normalizer
import time


def get_feature_correlations():
    start = time.time()
    feature_names = [feature.name for feature in IdxPost]
    X_1000_class, _ = data_generator.get_dataset(
        is_classification=True,
        target_prefix='mvto-1000-1',
        get_train_data=True,
        get_test_data=False
    )
    X_1000_reg, _ = data_generator.get_dataset(
        is_classification=False,
        target_prefix='mvto-1000-1',
        get_train_data=True,
        get_test_data=False
    )
    X_400_reg, _ = data_generator.get_dataset(
        is_classification=False,
        target_prefix='mvto-400-1',
        get_train_data=True,
        get_test_data=False
    )
    X_250_reg, _ = data_generator.get_dataset(
        is_classification=False,
        target_prefix='mvto-250-1',
        get_train_data=True,
        get_test_data=False
    )
    X_150_reg, _ = data_generator.get_dataset(
        is_classification=False,
        target_prefix='mvto-150-1',
        get_train_data=True,
        get_test_data=False
    )
    X_75_reg, _ = data_generator.get_dataset(
        is_classification=False,
        target_prefix='mvto-75-1',
        get_train_data=True,
        get_test_data=False
    )
    print(X_1000_class.shape)

    df_1000_class = pd.DataFrame(
        X_1000_class, columns=feature_names
    )
    df_1000_class = df_1000_class.corr(
        method='spearman',
        min_periods=X_1000_class.shape[0]
    )
    df_1000_reg = pd.DataFrame(
        X_1000_reg, columns=feature_names
    )
    df_1000_reg = df_1000_reg.corr(
        method='spearman',
        min_periods=X_1000_reg.shape[0]
    )
    df_400_reg = pd.DataFrame(
        X_400_reg, columns=feature_names
    )
    df_400_reg = df_400_reg.corr(
        method='spearman',
        min_periods=X_400_reg.shape[0]
    )
    df_250_reg = pd.DataFrame(
        X_250_reg, columns=feature_names
    )
    df_250_reg = df_250_reg.corr(
        method='spearman',
        min_periods=X_250_reg.shape[0]
    )
    df_150_reg = pd.DataFrame(
        X_150_reg, columns=feature_names
    )
    df_150_reg = df_150_reg.corr(
        method='spearman',
        min_periods=X_150_reg.shape[0]
    )
    df_75_reg = pd.DataFrame(
        X_75_reg, columns=feature_names
    )
    df_75_reg = df_75_reg.corr(
        method='spearman',
        min_periods=X_75_reg.shape[0]
    )

    # Print names of highly correlated feature pairs
    old_threshold = 1.01
    for threshold in [0.5]:
        print(f"PAIRS CORRELATED AT {threshold}")
        pairs_seen = []
        correlated_data = []
        for col_name in df_1000_class.columns:
            for row_name in df_1000_class.columns:
                if col_name == row_name:
                    continue
                if (col_name, row_name) in pairs_seen:
                    continue
                correlation = df_1000_class.at[row_name, col_name]
                if threshold <= abs(correlation) < old_threshold:
                    correlated_data.append(
                        (row_name, col_name, correlation)
                    )
                    pairs_seen.append(
                        (row_name, col_name)
                    )
        correlated_data.sort(key=lambda x: abs(x[2]), reverse=True)
        for data in correlated_data:
            row_name, col_name, correlation = data
            print(f"{row_name}, {col_name}, {correlation}")
        old_threshold = threshold
    # Develop histogram of correlation values
    histogram_data = []
    pairs_seen = []
    for col_name in df_1000_class.columns:
        for row_name in df_1000_class.columns:
            if col_name == row_name:
                continue
            if (col_name, row_name) in pairs_seen:
                continue
            correlation = df_1000_class.at[row_name, col_name]
            histogram_data.append(abs(correlation))
            pairs_seen.append(
                (row_name, col_name)
            )
    histogram_bins_1000_class = [0.9, 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1.0]
    histogram_counts_1000_class = [0 for _ in histogram_bins_1000_class]

    def populate_histogram_bins(hist_bins, hist_counts, hist_data):
        for hist_val in hist_data:
            for hist_idx, hist_bin in enumerate(hist_bins):
                if hist_val <= hist_bin:
                    hist_counts[hist_idx] += 1
                    break
    populate_histogram_bins(
        hist_bins=histogram_bins_1000_class,
        hist_counts=histogram_counts_1000_class,
        hist_data=histogram_data
    )
    print(histogram_counts_1000_class)

    # Calculate difference in correlations between mvto-75 and mvto-[150, 250, 400, 1000] in regression
    for df_comp in [df_150_reg, df_250_reg, df_400_reg, df_1000_reg]:
        df_diff = df_75_reg - df_comp

        # Print out the most different feature pairs
        # old_threshold = 1.01
        # for threshold in [0.7]:
        #     print(f"PAIRS DIFF AT {threshold}")
        #     pairs_seen = []
        #     correlated_data = []
        #     for col_name in df_diff.columns:
        #         for row_name in df_diff.columns:
        #             if col_name == row_name:
        #                 continue
        #             if (col_name, row_name) in pairs_seen:
        #                 continue
        #             correlation = df_diff.at[row_name, col_name]
        #             if threshold <= abs(correlation) < old_threshold:
        #                 correlated_data.append(
        #                     (row_name, col_name, correlation)
        #                 )
        #                 pairs_seen.append(
        #                     (row_name, col_name)
        #                 )
        #     correlated_data.sort(key=lambda x: abs(x[2]), reverse=True)
        #     for data in correlated_data:
        #         row_name, col_name, correlation = data
        #         print(f"{row_name}, {col_name}, {correlation}")
        #     old_threshold = threshold
        # Develop histogram of diff values
        histogram_bins_diff_reg = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        histogram_counts_diff_reg = [0 for _ in histogram_bins_diff_reg]
        histogram_data_diff_reg = []
        pairs_seen = []
        for col_name in df_diff.columns:
            for row_name in df_diff.columns:
                if col_name == row_name:
                    continue
                if (col_name, row_name) in pairs_seen:
                    continue
                correlation = df_diff.at[row_name, col_name]
                histogram_data_diff_reg.append(abs(correlation))
                pairs_seen.append(
                    (row_name, col_name)
                )
        populate_histogram_bins(
            hist_bins=histogram_bins_diff_reg,
            hist_counts=histogram_counts_diff_reg,
            hist_data=histogram_data_diff_reg
        )
        print(histogram_counts_diff_reg)
    end = time.time()
    print(f"Took {int(end - start)}s")


def get_important_inference_times():
    classifier_model_name_1k = "gradb_class"
    regressor_model_name_1k = "gradb_reg"
    classifier_name_1k = f"{classifier_model_name_1k.replace('_', '-').replace('tuned', 't')}-1k"
    regressor_name_1k = f"{regressor_model_name_1k.replace('_', '-').replace('tuned', 't')}-1k"
    classifier_model_name_400 = "gradb_class"
    regressor_model_name_400 = "gradb_reg"
    classifier_name_400 = f"{classifier_model_name_400.replace('_', '-').replace('tuned', 't')}-400"
    regressor_name_400 = f"{regressor_model_name_400.replace('_', '-').replace('tuned', 't')}-400"
    classifier_model_name_250 = "gradb_class"
    regressor_model_name_250 = "gradb_reg_tuned"
    classifier_name_250 = f"{classifier_model_name_250.replace('_', '-').replace('tuned', 't')}-250"
    regressor_name_250 = f"{regressor_model_name_250.replace('_', '-').replace('tuned', 't')}-250"
    classifier_model_name_150 = "erf_class"
    regressor_model_name_150 = "hgb_reg_tuned"
    classifier_name_150 = f"{classifier_model_name_150.replace('_', '-').replace('tuned', 't')}-150"
    regressor_name_150 = f"{regressor_model_name_150.replace('_', '-').replace('tuned', 't')}-150"

    # if args.loo_cv:
    #     test_prefix = f"vto-{args.dataset_max_iters}-{args.dataset_min_iters}-loocv"
    # else:
    #     test_prefix = f"ttnkoi-{args.dataset_max_iters}-{args.dataset_min_iters}"
    # if args.use_tuned:
    #     test_prefix = test_prefix + "-tuned"
    # test(
    #     is_classification=is_target_classification,
    #     test_prefix=test_prefix,
    #     train_prefix=args.train_prefix,
    #     dataset_max_iters=args.dataset_max_iters,
    #     test_min_iters=args.dataset_min_iters,
    #     use_tuned_models=args.use_tuned,
    #     is_loocv=args.loo_cv
    # )

    for model_name, train_prefix, max_iters in [
        (classifier_model_name_1k, "mvto-1000-1", 1000),
        (classifier_model_name_400, "mvto-400-1", 400),
        (classifier_model_name_250, "mvto-250-1", 250),
        (classifier_model_name_150, "mvto-150-1", 150),
        (regressor_model_name_1k, "mvto-1000-1", 1000),
        (regressor_model_name_400, "mvto-400-1", 400),
        (regressor_model_name_250, "mvto-250-1", 250),
        (regressor_model_name_150, "mvto-150-1", 150),
    ]:
        print(model_name)
        if "class" in model_name:
            is_classification = True
        else:
            is_classification = False
        # Load model
        if is_classification:
            target_models = [
                train_and_test.CustomClassifier(
                    name=model_name,
                    estimator=data_generator.load_trained_model(
                        is_classification=is_classification,
                        train_prefix=train_prefix,
                        model_name=model_name
                    )
                )
            ]
        else:
            target_models = [
                train_and_test.CustomRegressor(
                    name=model_name,
                    estimator=data_generator.load_trained_model(
                        is_classification=is_classification,
                        train_prefix=train_prefix,
                        model_name=model_name
                    )
                )
            ]
        test_prefix = f"ttnkoi{train_prefix.replace('mvto','')}"
        train_and_test.test_models(
            target_models=target_models,
            is_classification=is_classification,
            train_prefix=train_prefix,
            test_prefix=test_prefix,
            dataset_max_iters=max_iters,
            test_min_iters=1,
            is_loocv=False
        )


def get_tree_feature_importances():
    classifier_model_name_1k = "gradb_class"
    classifier_name_1k = f"{classifier_model_name_1k.replace('_', '-').replace('tuned', 't')}-1k"
    regressor_model_name_1k = "gradb_reg"
    regressor_name_1k = f"{regressor_model_name_1k.replace('_', '-').replace('tuned', 't')}-1k"
    classifier_model_name_400 = "gradb_class"
    regressor_model_name_400 = "gradb_reg"
    classifier_name_400 = f"{classifier_model_name_400.replace('_', '-').replace('tuned', 't')}-400"
    regressor_name_400 = f"{regressor_model_name_400.replace('_', '-').replace('tuned', 't')}-400"
    classifier_model_name_250 = "gradb_class"
    regressor_model_name_250 = "gradb_reg_tuned"
    classifier_name_250 = f"{classifier_model_name_250.replace('_', '-').replace('tuned', 't')}-250"
    regressor_name_250 = f"{regressor_model_name_250.replace('_', '-').replace('tuned', 't')}-250"
    classifier_model_name_150 = "erf_class"
    # regressor_model_name_150 = "hgb_reg_tuned"
    classifier_name_150 = f"{classifier_model_name_150.replace('_', '-').replace('tuned', 't')}-150"
    # regressor_name_150 = f"{regressor_model_name_150.replace('_', '-').replace('tuned', 't')}-150"
    # classifier_model_name_75 = "hgb_class_tuned"
    # regressor_model_name_75 = "hgb_reg_tuned"
    # classifier_name_75 = f"{classifier_model_name_75.replace('_', '-').replace('tuned', 't')}-75"
    # regressor_name_75 = f"{regressor_model_name_75.replace('_', '-').replace('tuned', 't')}-75"

    all_models = [
        (classifier_model_name_1k, classifier_name_1k, "mvto-1000-1"),
        (classifier_model_name_400, classifier_name_400, "mvto-400-1"),
        (classifier_model_name_250, classifier_name_250, "mvto-250-1"),
        (classifier_model_name_150, classifier_name_150, "mvto-150-1"),
        (regressor_model_name_1k, regressor_name_1k, "mvto-1000-1"),
        (regressor_model_name_400, regressor_name_400, "mvto-400-1"),
        (regressor_model_name_250, regressor_name_250, "mvto-250-1")
    ]

    all_feature_importances_sum = [0 for _ in range(81)]
    class_feature_importances_sum = [0 for _ in range(81)]
    reg_feature_importances_sum = [0 for _ in range(81)]

    feature_names = [feature.name for feature in IdxPost]
    for model_idx, model_tuple in enumerate(all_models):
        model_name, printable_model_name, prefix = model_tuple
        if "class" in model_name:
            is_classification = True
        else:
            is_classification = False
        tree_ensemble_estimator = data_generator.load_trained_model(
            is_classification=is_classification,
            train_prefix=prefix,
            model_name=model_name
        )
        feature_importances = tree_ensemble_estimator.feature_importances_
        assert len(feature_names) == len(feature_importances)
        all_feature_importances_sum += feature_importances
        if is_classification:
            class_feature_importances_sum += feature_importances
        else:
            reg_feature_importances_sum += feature_importances
        print(printable_model_name)
        for feature_importance in feature_importances:
            print(f"{feature_importance},", end='')
        print()
    for feature_name in feature_names:
        print(f"{feature_name},", end='')
    print()
    print("All feature importances")
    for feature_importance in all_feature_importances_sum:
        print(f"{feature_importance},", end='')
    print()
    print("Class feature importances")
    for feature_importance in class_feature_importances_sum:
        print(f"{feature_importance},", end='')
    print()
    print("Reg feature importances")
    for feature_importance in reg_feature_importances_sum:
        print(f"{feature_importance},", end='')
    print()


def combine_sim_partition_results(is_vtr_mode=False):
    base_path = path.dirname(__file__)
    sim_results_dir = path.abspath(
        path.join(
            base_path, '..', 'results', 'simulator'
        )
    )

    if not is_vtr_mode:
        combined_results_filepath = path.abspath(
            path.join(
                base_path, '..', 'results', 'official', 'partitioned_sim_optimized_results.csv'
            )
        )
    else:
        combined_results_filepath = path.abspath(
            path.join(
                base_path, '..', 'results', 'official', 'vtr_sim_results.csv'
            )
        )
    header = f"Partitions, Max Iters, Window Size, Threshold, TN, FP, FN, TP, " + \
        f"Iters Wasted R, Iter Count R, Iters Wasted U, " + \
        f"ML Time Wasted R, Time Wasted R, Tot. Time R, " + \
        f"ML Time Wasted U, Time Wasted U, " + \
        f"ML Time Saved U, Time Saved U, Iters Saved U, " + \
        f"ML Time Wasted Tot., ML Time Tot., " + \
        f"Time Wasted Tot., Time Tot., " + \
        f"Iters Wasted Tot., Iters Tot., True Recall, Time/Success\n"

    with open(combined_results_filepath, 'wt') as outfile:
        outfile.write(header)
        for filename in os.listdir(sim_results_dir):
            if not is_vtr_mode:
                if not filename.startswith('p0_') and not filename.startswith('p1_') and \
                        not filename.startswith('p2_') and not filename.startswith('p3_') and \
                        not filename.startswith('p4_'):
                    continue
            else:
                if not filename.startswith('vtr_'):
                    continue
            filename_tokens = filename.split('_')
            if not is_vtr_mode:
                num_partitions = filename_tokens[0].replace('p', '')
            else:
                num_partitions = 0
            max_iters = filename_tokens[2].replace('t', '').replace('.csv', '')
            infile_path = path.abspath(
                path.join(
                    sim_results_dir, filename
                )
            )
            with open(infile_path, 'rt') as infile:
                for line_idx, line in enumerate(infile):
                    if line_idx == 0:
                        # header
                        continue
                    outfile.write(f"{num_partitions},{max_iters},")
                    outfile.write(line)


def find_best_hparam_combs():
    tuned_model_data_list = [
        ["sgd_class", 1000, [316, 586, 856, 1126]],
        ["sgd_class", 400, [131, 116]],
        ["sgd_class", 250, [199]],
        ["sgd_class", 150, [229]],
        ["sgd_class", 75, [11]],
        ["hgb_class", 1000, [311]],
        ["hgb_class", 400, [215]],
        ["hgb_class", 250, [35]],
        ["hgb_class", 150, [179]],
        ["hgb_class", 75, [348]],
        ["gradb_class", 1000, [11]],
        ["gradb_class", 400, [17]],
        ["gradb_class", 250, [10]],
        ["gradb_class", 150, [17]],
        ["gradb_class", 75, [11]],
        ["erf_class", 1000, [195, 211]],
        ["erf_class", 400, [195, 211]],
        ["erf_class", 250, [192]],
        ["erf_class", 150, [131, 163, 179]],
        ["erf_class", 75, [200]],
        ["rf_class", 1000, [60, 66]],
        ["rf_class", 400, [62, 68]],
        ["rf_class", 250, [64, 70]],
        ["rf_class", 150, [63, 69]],
        ["rf_class", 75, [48, 54]],
        ["adab_class", 1000, [31]],
        ["adab_class", 400, [31]],
        ["adab_class", 250, [31]],
        ["adab_class", 150, [18]],
        ["adab_class", 75, [28]],
        ["omp_reg", 1000, [12]],
        ["omp_reg", 400, [1]],
        ["omp_reg", 250, [5]],
        ["omp_reg", 150, [5]],
        ["omp_reg", 75, [13]],
        ["hgb_reg", 1000, [28, 84, 140]],
        ["hgb_reg", 400, [522, 578, 634]],
        ["hgb_reg", 250, [1891, 1947, 2003]],
        ["hgb_reg", 150, [691, 747, 803]],
        ["hgb_reg", 75, [201, 257, 313]],
        ["gradb_reg", 1000, [89, 81]],
        ["gradb_reg", 400, [6]],
        ["gradb_reg", 250, [37, 39]],
        ["gradb_reg", 150, [5, 7]],
        ["gradb_reg", 75, [8]],
        ["bag_reg", 1000, [39]],
        ["bag_reg", 400, [27]],
        ["bag_reg", 250, [50]],
        ["bag_reg", 150, [13]],
        ["bag_reg", 75, [13]],
        ["rf_reg", 1000, [30]],
        ["rf_reg", 400, [41]],
        ["rf_reg", 250, [15]],
        ["rf_reg", 150, [36]],
        ["rf_reg", 75, [44]],
        ["erf_reg", 1000, [73]],
        ["erf_reg", 400, [67]],
        ["erf_reg", 250, [74]],
        ["erf_reg", 150, [76]],
        ["erf_reg", 75, [95]],
        ["adab_reg", 1000, [25]],
        ["adab_reg", 400, [3]],
        ["adab_reg", 250, [18]],
        ["adab_reg", 150, [14]],
        ["adab_reg", 75, [13]],
    ]
    tuned_model_data_list.sort(key=lambda x: x[1], reverse=True)
    random_state = 0
    hparams = {
        "sgd_class": {
            "loss": ("'hinge'", "'log'", "'modified_huber'", "'squared_hinge'", "'perceptron'"),  # log
            "penalty": ("'l2'", "'l1'", "'elasticnet'"),  # l2
            "alpha": (0.1, 0.09, 0.08, 0.07, 0.05, 0.04, 0.03, 0.02, 0.01,
                      0.009, 0.008, 0.007, 0.006, 0.005, 0.004, 0.003, 0.002, 0.001),  # 0.07
            "max_iter": (5, 7, 10, 15, 20),  # 7
        },
        "rf_class": {
            "max_features": (40, None),  #
            "n_estimators": (70, 100, 130),  #
            "max_depth": (16, None),  #
            "min_samples_split": [2],  #
            "min_impurity_decrease": (0.03, 0.02, 0.01, 0.008, 0.005, 0.001)  #
        },
        "erf_class": {
            "max_features": (20, 30, 40, None),  #
            "n_estimators": (75, 100, 125, 150),  #
            "max_depth": (12, 16, 24, None),  #
            "min_samples_split": [2],  #
            "min_impurity_decrease": (0.1, 0.01, 0.001, 0.0)  #
        },
        "adab_class": {
            "base_estimator": (tree.DecisionTreeClassifier(random_state=random_state, max_depth=3),
                               tree.DecisionTreeClassifier(random_state=random_state, max_depth=2),
                               tree.DecisionTreeClassifier(random_state=random_state, max_depth=1)),
            #
            "n_estimators": (100, 150, 200),  #
            "learning_rate": (0.05, 0.1, 0.5),  #
            "algorithm": ("'SAMME'", "'SAMME.R'"),  #
        },
        "gradb_class": {
            "n_estimators": (50, 75),  #
            "learning_rate": (0.01, 0.05, 0.075),  #
            "max_depth": (2, 3, 4),  #
            "subsample": [1.0],  #
            "max_features": [None]  #
        },
        "hgb_class": {
            "learning_rate": (0.05, 0.1, 0.5),  #
            "max_iter": (5, 10, 20),  #
            "max_depth": (3, 4, 8, None),  #
            "l2_regularization": (0.01, 0.05, 0.1, 0.5, 1.0),  #
            "max_bins": (31, 63, 95)  #
        },
        "omp_reg": {
            "n_nonzero_coefs": (None, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
                                12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
                                23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
                                34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44,
                                45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
                                56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66,
                                67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
                                78, 79, 80)  #
            #
        },
        "bag_reg": {
            "base_estimator": [
                None  #
            ],
            "n_estimators": (20, 30, 40, 50),  #
            "max_samples": (0.1, 0.5, 1.0),  #
            "max_features": (0.6, 0.8, 1.0),  #
            "bootstrap": (False, True),  #
            "bootstrap_features": [True]
        },
        "adab_reg": {
            "base_estimator": (
                tree.DecisionTreeRegressor(
                    random_state=random_state, max_depth=20
                ),
                tree.DecisionTreeRegressor(
                    random_state=random_state, max_depth=24
                ),
                tree.DecisionTreeRegressor(
                    random_state=random_state, max_depth=32
                ),
            ),  #
            "n_estimators": (75, 100, 125),  #
            "learning_rate": (0.6, 0.5, 0.4),  #
            "loss": ["'square'"]  #
        },
        "rf_reg": {
            "criterion": ["'squared_error'"],  #
            "max_depth": (8, 16, 24),  #
            "min_impurity_decrease": (0.01, 0.001, 0.0005, 0.0001),  #
            "ccp_alpha": (0.001, 0.005, 0.01, 0.1)  #
        },
        "erf_reg": {
            "n_estimators": (75, 100, 150),  #
            "max_depth": (8, 16, 24),  #
            "min_samples_split": [2],  #
            "max_features": (0.2, 0.6, None),  #
            "min_impurity_decrease": (0.001, 0.0001),  #
            "ccp_alpha": (0.001, 0.01)  #
        },
        "gradb_reg": {
            "loss": ("'squared_error'", "'absolute_error'"),  #
            "criterion": ("'friedman_mse''", "'squared_error'"),  #
            "n_estimators": (75, 100, 150),  #
            "subsample": (0.25, 0.5, 0.75),  #
            "learning_rate": (0.075, 0.1, 0.15)  #
        },
        "hgb_reg": {
            "loss": ("'squared_error'", "'absolute_error'"),  # absolute
            "learning_rate": (0.05, 0.025, 0.1, 0.2, 0.4, 0.8, 1.0),  #
            "max_iter": (25, 50, 75, 100),  #
            "max_depth": (32, 48, None),  #
            "l2_regularization": (0, 0.001, 0.01, 0.1),  #
            "max_bins": (127, 191, 255),  #
        }
    }

    def print_matching_hparams(hparam_dict, target_hparam_comb_num, hparam_keys, hparam_key_idx, hparam_comb_num, hparam_string):
        hparam_key = hparam_keys[hparam_key_idx]
        if hparam_key_idx == 0:
            for hparam_val in hparam_dict[hparam_key]:
                new_hparam_string = f"{hparam_string},{hparam_key}={hparam_val}"
                if hparam_comb_num[0] == target_hparam_comb_num:
                    print(new_hparam_string)
                    hparam_comb_num[0] = hparam_comb_num[0] + 1
                else:
                    hparam_comb_num[0] = hparam_comb_num[0] + 1
        else:
            for hparam_val in hparam_dict[hparam_key]:
                new_hparam_string = f"{hparam_string},{hparam_key}={hparam_val}"
                print_matching_hparams(
                        hparam_dict=hparam_dict,
                        target_hparam_comb_num=target_hparam_comb_num,
                        hparam_keys=hparam_keys,
                        hparam_key_idx=hparam_key_idx-1,
                        hparam_comb_num=hparam_comb_num,
                        hparam_string=new_hparam_string
                )


    for tuned_model_data in tuned_model_data_list:
        model_name = tuned_model_data[0]
        target_iters = tuned_model_data[1]
        optimal_hparam_combs = tuned_model_data[2]
        hparam_dict = hparams[model_name]
        hparam_keys = list(hparam_dict.keys())
        for optimal_hparam_comb in optimal_hparam_combs:
            print(f"{model_name},{target_iters},{optimal_hparam_comb}: ", end="")
            print_matching_hparams(
                hparam_dict=hparam_dict,
                target_hparam_comb_num=optimal_hparam_comb,
                hparam_keys=hparam_keys,
                hparam_key_idx=len(hparam_keys) - 1,
                hparam_comb_num=[0],
                hparam_string=""
            )

def process_partial_tuning_results():
    base_path = path.dirname(__file__)
    tune_class_path = path.abspath(
        path.join(
            base_path, "..", "results", "classification", "tuning"
        )
    )
    tune_reg_path = path.abspath(
        path.join(
            base_path, "..", "results", "regression", "tuning"
        )
    )

    for tune_dir_path in [tune_class_path, tune_reg_path]:
        for intermediary_tune_results_filename in os.listdir(tune_dir_path):
            if "intermediary" not in intermediary_tune_results_filename:
                continue

            print(f"Processing {intermediary_tune_results_filename}")

            if "_class_" in intermediary_tune_results_filename:
                is_classification = True
            elif "_reg" in intermediary_tune_results_filename:
                is_classification = False
            else:
                is_classification = None
                exit(f"ERROR: Bad filename {intermediary_tune_results_filename}")

            intermediary_filepath = path.abspath(
                path.join(
                    tune_dir_path, intermediary_tune_results_filename
                )
            )

            with open(intermediary_filepath, 'rt') as infile:
                # Find % of tuning that was completed
                num_folds_completed = 0
                old_fold_idx = "0"
                num_hyperparam_combs = 0
                combs_this_fold = 0
                is_finished_first_fold = False
                for line in infile:
                    combs_this_fold += 1
                    if not is_finished_first_fold:
                        num_hyperparam_combs += 1
                        tokens = line.split(',')
                        fold_idx = tokens[0]
                        if fold_idx != old_fold_idx:
                            is_finished_first_fold = True
                            num_hyperparam_combs += -1
                            combs_this_fold = 1
                            num_folds_completed += 1
                    else:
                        if combs_this_fold == num_hyperparam_combs:
                            num_folds_completed += 1
                            combs_this_fold = 0

                if num_folds_completed == 0:
                    continue

                completion_percent = int(100.0*float(num_folds_completed)/5.0)

                name_extension = intermediary_tune_results_filename.replace("results_intermediary_", "")
                partial_tune_results_filename = f"results_{completion_percent}p_{name_extension}"
                partial_tune_results_path = path.abspath(
                    path.join(
                        tune_dir_path, partial_tune_results_filename
                    )
                )

                results_full = []
                for hparam_idx in range(num_hyperparam_combs):
                    if is_classification:
                        results_full.append(
                            [0, 0, 0, 0]
                        )
                    else:
                        results_full.append(
                            [0, 0, 0, 0, 0, 0, 0, 0]
                        )

                infile.seek(0)
                for line in infile:
                    tokens = line.split(',')
                    fold_idx = int(tokens[0])
                    if fold_idx >= num_folds_completed:
                        continue
                    hparam_comb_num = int(tokens[1])
                    if is_classification:
                        tn = int(tokens[2])
                        fp = int(tokens[3])
                        fn = int(tokens[4])
                        tp = int(tokens[5].strip())
                        results_full[hparam_comb_num][0] += tn
                        results_full[hparam_comb_num][1] += fp
                        results_full[hparam_comb_num][2] += fn
                        results_full[hparam_comb_num][3] += tp
                    else:
                        mae = float(tokens[2])
                        mape = float(tokens[3])
                        medae = float(tokens[4])
                        mse = float(tokens[5])
                        evs = float(tokens[6])
                        max_err = float(tokens[7])
                        r2 = float(tokens[8])
                        num_datapoints = int(tokens[9].strip())
                        results_full[hparam_comb_num][0] += mae * num_datapoints
                        results_full[hparam_comb_num][1] += mape * num_datapoints
                        results_full[hparam_comb_num][2] += medae * num_datapoints
                        results_full[hparam_comb_num][3] += mse * num_datapoints
                        results_full[hparam_comb_num][4] += evs * num_datapoints
                        results_full[hparam_comb_num][5] += max_err * num_datapoints
                        results_full[hparam_comb_num][6] += r2 * num_datapoints
                        results_full[hparam_comb_num][7] += num_datapoints
                for hparam_idx, data_list in enumerate(results_full):
                    if is_classification:
                        tn_full = data_list[0]
                        fp_full = data_list[1]
                        fn_full = data_list[2]
                        tp_full = data_list[3]
                        class_metrics = calculate_class_metrics(
                            true_neg=tn_full,
                            false_pos=fp_full,
                            false_neg=fn_full,
                            true_pos=tp_full
                        )
                        acc, false_prec, false_rec, true_prec, true_rec, mcc = class_metrics
                        results_full[hparam_idx].append(acc)
                        results_full[hparam_idx].append(false_prec)
                        results_full[hparam_idx].append(false_rec)
                        results_full[hparam_idx].append(true_prec)
                        results_full[hparam_idx].append(true_rec)
                        results_full[hparam_idx].append(mcc)
                    else:
                        num_datapoints = data_list[-1]
                        for data_idx in range(7):
                            assert num_datapoints > 0, f"{hparam_idx}: {data_list}"
                            results_full[hparam_idx][data_idx] /= num_datapoints

                with open(partial_tune_results_path, 'wt') as outfile:
                    if is_classification:
                        outfile.write("Hyperparam Idx,TN,FP,FN,TP,Acc,False Prec,False Rec,True Prec,True Rec,MCC\n")
                    else:
                        outfile.write("Hyperparam Idx,MAE,MAPE,MedAE,MSE,EVS,MAX ERR,R^2,Num Datapoints\n")
                    for hparam_idx, data_list in enumerate(results_full):
                        outfile.write(f"{hparam_idx}")
                        for data in data_list:
                            outfile.write(f",{data}")
                        outfile.write('\n')


def convert_circuit_tables_to_classifier_tables():
    base_path = path.dirname(__file__)
    results_csv_path = path.abspath(
        path.join(
            base_path, "..", "results", "results.csv"
        )
    )
    adjusted_results_path = path.abspath(
        path.join(
            base_path, "..", "results", "results_adjusted.csv"
        )
    )
    classifiers = [
        'KNeighborsClassifier()',
        'MLPClassifier()',
        'SGDClassifier()',
        'RidgeClassifier()',
        'PassiveAggressiveClassifier()',
        'GaussianNB()',
        'DecisionTreeClassifier()',
        'RandomForestClassifier()',
        'ExtraTreesClassifier()',
        'AdaBoostClassifier()',
        'GradientBoostingClassifier()',
        'VTR'
    ]

    with open(adjusted_results_path, 'wt') as outfile:
        for classifier_name in classifiers:
            with open(results_csv_path, 'rt') as infile:
                outfile.write(f"\n\n\n{classifier_name}\n")
                outfile.write(f"Circuit Name,TN,FN,FP,TP\n")
                active_circuit_name = ""
                for line in infile:
                    tn = -1
                    fp = -1
                    fn = -1
                    tp = -1
                    tokens = line.split(',')
                    tokens = [element for element in tokens if element != '' and element != '\n']
                    if len(tokens) == 1:
                        active_circuit_name = tokens[0].strip()
                    if classifier_name in line:
                        tokens = line.split(',')
                        tn = tokens[1]
                        fp = tokens[2]
                        fn = tokens[3]
                        tp = tokens[4].strip()
                        outfile.write(f"{active_circuit_name},{tn},{fp},{fn},{tp}\n")


def convert_results_txt_to_csv():
    base_path = path.dirname(__file__)
    results_txt_path = path.abspath(
        path.join(
            base_path, "..", "results", "results.txt"
        )
    )
    results_csv_path = path.abspath(
        path.join(
            base_path, "..", "results", "results.csv"
        )
    )
    with open(results_csv_path, 'wt') as outfile:
        with open(results_txt_path, 'rt') as infile:
            active_classifier_name = ""
            for line in infile:
                tn, fp, fn, tp = 0, 0, 0, 0
                if "Test circuit is" in line:
                    tokens = line.split(' ')
                    circuit_name = tokens[-1].strip()
                    outfile.write(f"\n\n{circuit_name}\n")
                    outfile.write(f"Classifier,TN,FP,FN,TP\n")
                if "- classifier" in line:
                    tokens = line.split(' ')
                    active_classifier_name = tokens[0]
                if "[[" in line and "]]" in line:
                    outfile.write(f"{active_classifier_name},0,0,0,0\n")  # Will need to manually overwrite this
                elif "[[" in line:
                    tokens = line.split(' ')
                    tokens = [element for element in tokens if element != '']
                    tn = tokens[0].replace('[', '')
                    if not tn.isdecimal():
                        tn = tokens[1]
                        fp = tokens[2].strip().replace(']', '')
                    else:
                        fp = tokens[1].strip().replace(']', '')
                    outfile.write(f"{active_classifier_name},{tn},{fp},")
                elif "]]" in line:
                    tokens = line.split(' ')
                    tokens = [element for element in tokens if element != '']
                    fn = tokens[0].replace('[', '')
                    if not fn.isdecimal():
                        fn = tokens[1]
                        tp = tokens[2].strip().replace(']', '')
                    else:
                        tp = tokens[1].strip().replace(']', '')
                    outfile.write(f"{fn},{tp}\n")


if __name__ == "__main__":
    get_feature_correlations()
