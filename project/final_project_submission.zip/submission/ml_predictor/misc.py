"""
For functions that don't fit any particular category of purpose.
"""
import math
import os
from os import path
import re
from raw_data_processor import get_route_fingerprint_from_line
from constants import Idx, VTR_MAX_ITERS, MCNC_VTR_CIRCUIT_NAMES, \
    KOIOS_CIRCUIT_NAMES, TITAN_CIRCUIT_NAMES, VALID_CIRCUIT_NAMES, TOTHER_CIRCUIT_NAMES
import matplotlib.pyplot as plt
from warnings import warn


def check_channel_widths(min_chan_width_distance=20):
    """
    For all the currently processed routing data:
    1) Find the minimum channel width
    2) Check that the target number of routable and unroutable circuits above and below the minimum have been completed
    3) Report minimum channel widths and any circuits missing from the target numbers
    :return:
    """
    max_iters = VTR_MAX_ITERS
    # circuit_names_to_skip = ["tseng", "alu4", "apex2", "apex4", "bigkey", "clma", "des", "diffeq", "dsip", "elliptic",
    #                          "ex1010", "ex5p", "frisc", "misex3", "pdc", "s298", "s38417", "s38584.1", "seq", "spla",
    #                          "stereovision3", "ch_intrinsics", "boundtop", "diffeq1", "diffeq2", "mkPktMerge",
    #                          "raygentop", "mkSMAdapter4B", "stereovision0", "or1200", "mkDelayWorker32B", "blob_merge",
    #                          "stereovision1", "sha", "bgm", "stereovision2", "LU8PEEng", "mcml", "LU32PEEng"]
    circuit_names_to_skip = []
    route_completion_data = []
    route_comparison_data = []
    unroutable_target = 2
    routable_target = 2
    num_unroutable_to_redo = 0
    num_routable_to_redo = 0
    num_negatives = 0
    negative_list = []

    # Get relative path to processed data directory
    base_path = path.dirname(__file__)
    processed_data_dir_path = path.abspath(path.join(base_path, "..", "processed_routing_data"))
    for filename in os.listdir(processed_data_dir_path):
        circuit_name = re.sub(r'_\d_data.csv', '', filename)
        if circuit_name not in VALID_CIRCUIT_NAMES or not re.search(r'_\d_data.csv', filename):
            warn(f"Skipping '{filename}' because it is invalid")
            continue
        if circuit_name in circuit_names_to_skip:
            continue
        print(f"{filename}")
        target_path = path.abspath(
            path.join(
                processed_data_dir_path, filename
            )
        )

        with open(target_path, 'rt') as infile:
            old_line = None
            routing_fingerprint = None
            routing_attempt_length = 0
            for line_idx, line in enumerate(infile):
                if line_idx == 0:
                    # Skip header
                    continue

                new_routing_attempt = False
                if line_idx == 1:
                    # This is the first data line of the file
                    # Initialize variables

                    # Identify a routing attempt by its fingerprint
                    routing_fingerprint = get_route_fingerprint_from_line(line)
                    routing_attempt_length = 1
                else:
                    # Check for routing attempt change
                    new_line_fingerprint = get_route_fingerprint_from_line(line)
                    for i in range(len(routing_fingerprint)):
                        if routing_fingerprint[i] != new_line_fingerprint[i]:
                            # This line is from a new routing attempt
                            #print(routing_fingerprint)
                            #print(new_line_fingerprint)
                            #print(f"Routing attempt change!: {routing_fingerprint[i]} != {new_line_fingerprint[i]}")
                            new_routing_attempt = True

                    if new_routing_attempt:
                        old_tokens = old_line.split(',')
                        old_completion_iter = int(old_tokens[Idx.TRUE_ITER.value].strip())
                        old_channel_width = int(old_tokens[Idx.CHAN_WIDTH.value].strip())
                        old_placer_seed = int(old_tokens[Idx.PLACE_SEED.value].strip())
                        if abs(old_completion_iter) <= max_iters:
                            assert abs(old_completion_iter) - 1 == routing_attempt_length, \
                                f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
                        else:
                            assert max_iters - 1 == routing_attempt_length, \
                                f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
                        # Record number of iters, linearity, and VTR mae
                        route_completion_data.append(
                            (old_completion_iter,
                             circuit_name,
                             old_placer_seed,
                             old_channel_width)
                        )
                        route_comparison_data.append(
                            (circuit_name,
                             old_placer_seed,
                             old_channel_width)
                        )
                        # Reset for new routing attempt
                        routing_fingerprint = get_route_fingerprint_from_line(line)
                        routing_attempt_length = 1
                    else:
                        routing_attempt_length += 1
                old_line = line
            # Handle case of last routing attempt in file
            old_tokens = old_line.split(',')
            old_completion_iter = int(old_tokens[Idx.TRUE_ITER.value].strip())
            old_channel_width = int(old_tokens[Idx.CHAN_WIDTH.value].strip())
            old_placer_seed = int(old_tokens[Idx.PLACE_SEED.value].strip())
            if abs(old_completion_iter) <= max_iters:
                assert abs(old_completion_iter) - 1 == routing_attempt_length, \
                    f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
            else:
                assert max_iters - 1 == routing_attempt_length, \
                    f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
            # Record number of iters, linearity, and VTR mae
            route_completion_data.append(
                (old_completion_iter,
                 circuit_name,
                 old_placer_seed,
                 old_channel_width)
            )
            route_comparison_data.append(
                (circuit_name,
                 old_placer_seed,
                 old_channel_width)
            )

    # Find minimum channel width for each circuit and corresponding routing iterations
    route_completion_data.sort(key=lambda x: x[1], reverse=False)
    min_width_iters = {}
    completion_type_counts = {}
    for completion_iter, name, seed, chan_width in route_completion_data:
        route_key = (name, seed)
        if route_key not in completion_type_counts:
            completion_type_counts[route_key] = [0, 0, 0]
        if route_key not in min_width_iters:
            min_width_iters[route_key] = (2048, -1)
        if completion_iter < -1 or completion_iter > max_iters:
            continue  # Unroutable
        best_width, best_completion_iter = min_width_iters[route_key]
        if chan_width < best_width:
            min_width_iters[route_key] = (chan_width, completion_iter)

    # In case there is no data for a given seed of a circuit, add them in with default data
    route_key_list = []
    for route_key in completion_type_counts.keys():
        name, seed = route_key
        for seed in range(0, 5):
            if (name, seed) not in route_key_list:
                route_key_list.append(
                    (name, seed)
                )
    for route_key in route_key_list:
        if route_key not in completion_type_counts:
            completion_type_counts[route_key] = [0, 0, 0]
        if route_key not in min_width_iters:
            min_width_iters[route_key] = (2048, -1)

    # Count the number of route attempts below and above the minimum channel width per circuit-placer combo
    BELOW_COUNT_IDX = 0
    ABOVE_COUNT_U_IDX = 1
    ABOVE_COUNT_R_IDX = 2
    for completion_iter, name, seed, chan_width in route_completion_data:
        route_key = (name, seed)
        min_chan_width, completion_iter_min_width = min_width_iters[route_key]
        if chan_width < min_chan_width:
            completion_type_counts[route_key][BELOW_COUNT_IDX] += 1
        if chan_width > min_chan_width:
            if completion_iter < -1 or completion_iter > max_iters:
                completion_type_counts[route_key][ABOVE_COUNT_U_IDX] += 1
            elif completion_iter > 0:
                completion_type_counts[route_key][ABOVE_COUNT_R_IDX] += 1
            else:
                exit(f"ERROR: Bad completion iter: {completion_iter}")

    for route_key in route_key_list:
        name, seed = route_key
        below_count, above_count_u, above_count_r = completion_type_counts[route_key]
        min_chan_width, completion_iter = min_width_iters[route_key]
        if name in TITAN_CIRCUIT_NAMES or name in TOTHER_CIRCUIT_NAMES:
            if min_chan_width == 86:
                pass  # Titan architecture can't go below 86 tracks per channel, seemingly
            else:
                num_unroutable_to_redo += max(0, unroutable_target - below_count)
        else:
            num_unroutable_to_redo += max(0, unroutable_target-below_count)
        num_routable_to_redo += max(0, routable_target-above_count_r)
        if min_chan_width == 2048:
            num_negatives += 1
            negative_list.append(f"{name}_{seed}")
        if below_count < unroutable_target or above_count_r < routable_target:
            print(f"{name}, {seed}, {min_chan_width}, {below_count}, {above_count_u}, {above_count_r}")
    print(f"#Unroutable needed: {num_unroutable_to_redo} | #Routable needed: {num_routable_to_redo}")
    print(f"# Negatives: {num_negatives}")
    print(negative_list)

    # Print out minimum channel widths of all circuits
    route_key_list.sort(key=lambda x: x[1])
    route_key_list.sort(key=lambda x: x[0])
    for route_key in route_key_list:
        name, seed = route_key
        min_chan_width, completion_iter = min_width_iters[route_key]
        below_count, above_count_u, above_count_r = completion_type_counts[route_key]

        target_chan_widths = [min_chan_width]
        for i in range(routable_target + above_count_u):
            target_chan_widths.append(min_chan_width + 2*(i+1))
        if below_count == 0:
            for i in range(2*unroutable_target):
                target_chan_widths.append(min_chan_width - 2*(i+1))
        else:
            for i in range(unroutable_target):
                target_chan_widths.append(min_chan_width - 2*(i+1))
        if min_chan_width == 2048:
            test_width = 0
            for alt_route_key in route_key_list:
                alt_name, alt_seed = alt_route_key
                if name == alt_name and seed != alt_seed:
                    alt_min_chan_width, _ = min_width_iters[alt_route_key]
                    if alt_min_chan_width != 2048:
                        test_width = max(test_width, alt_min_chan_width)
            if test_width == 0:
                target_chan_widths = []
                warn(f"WARNING: Could not recommend any channel widths to run for {name}_{seed}!")
            else:
                # In case previous attempts have been made at finding min chan width through this method,
                # Bump up the target channel widths until the targets are an untried set of numbers
                while (name, seed, test_width+4) in route_comparison_data or \
                        (name, seed, test_width+12) in route_comparison_data:
                    test_width += 2
                target_chan_widths = [test_width+12, test_width+10, test_width+8, test_width+6, test_width+4]

        # if name in TOTHER_CIRCUIT_NAMES:
        #     # Different method for picking target channel widths
        #     target_chan_widths = [
        #         min_chan_width-2, min_chan_width-4, min_chan_width-6, min_chan_width-8, min_chan_width-10
        #     ]
        #     if min_chan_width == 100:
        #         target_chan_widths = [
        #             90, 80, 70, 60, 50
        #         ]
        # Titan architecture circuits with MCW == 86 (the titan minimum)
        for target_chan_width in target_chan_widths:
            if (name in TITAN_CIRCUIT_NAMES or name in TOTHER_CIRCUIT_NAMES) and target_chan_width < 86:
                if (name, seed, target_chan_width) not in route_comparison_data and target_chan_width < 1024:
                    print(f'("{name}","{seed}","{target_chan_width}"),')
                continue  # Titan architecture seems to require at least 86 tracks per channel
        # General circuits that need more routing
        # for target_chan_width in target_chan_widths:
        #     if name in VALID_CIRCUIT_NAMES:
        #         # Check if the target chan width has already been performed
        #         # If not, print it out to indicate we should run a routing attempt at this chan width
        #         if (name, seed, target_chan_width) not in route_comparison_data and target_chan_width < 1024:
        #             print(f'("{name}","{seed}","{target_chan_width}"),')



if __name__ == "__main__":
    check_channel_widths()
