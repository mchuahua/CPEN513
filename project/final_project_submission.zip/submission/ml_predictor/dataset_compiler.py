"""
For taking processed VPR data distributed across files and compiling them into a single dataset.
"""

from constants import Idx, VTR_NA_VALUE, VTR_MAX_ITERS, \
    VTR_INF_INTERPRETATION, DEFAULT_FEATURE_IGNORE_LIST, KOIOS_CIRCUIT_NAMES, TITAN_CIRCUIT_NAMES
from raw_data_processor import VALID_CIRCUIT_NAMES, get_route_fingerprint_from_line
import os
from os import path
import math
from sklearn.linear_model import LinearRegression
import re
from warnings import warn

def compile_dataset(
        feature_ignore_list=None, test_circuit_names=None,
        excluded_circuit_names=None, included_circuit_names=VALID_CIRCUIT_NAMES,
        outfile_name_prefix="", is_classification=False,
        compile_train=True, compile_test=True,
        test_data_max_iters=VTR_MAX_ITERS, train_data_max_iters=VTR_MAX_ITERS,
        test_data_min_iters=1, train_data_min_iters=1,
        is_verbose=False
):
    if feature_ignore_list is None:
        feature_ignore_list = DEFAULT_FEATURE_IGNORE_LIST
    if excluded_circuit_names is None:
        excluded_circuit_names = []  

    # Get relative path to processed data directory
    base_path = path.dirname(__file__)
    processed_data_dir_path = path.abspath(path.join(base_path, "..", "processed_routing_data"))
    # print(processed_data_dir_path)
    # Create the test dataset
    if compile_test:
        test_file_paths = []
        for filename in os.listdir(processed_data_dir_path):
            # print(filename[:-4])
           
            # File is valid for compiling
            if is_verbose:
                print(f"Compiling {filename} in test data")
            test_file_paths.append(
                path.abspath(
                    path.join(
                        processed_data_dir_path, filename
                    )
                )
            )
        test_prefix = f"{outfile_name_prefix}_test"
        # print(is_classification)
        if is_classification:
            create_class_dataset_from_files(
                filepath_list=test_file_paths,
                outfile_name_prefix=test_prefix,
                feature_ignore_list=feature_ignore_list,
                class_threshold=test_data_max_iters,
                min_iters=test_data_min_iters
            )
            # print('clasffication')
        else:
            create_reg_dataset_from_files(
                test_file_paths,
                outfile_name_prefix=test_prefix,
                feature_ignore_list=feature_ignore_list,
                max_iters=test_data_max_iters,
                min_iters=test_data_min_iters
            )
            # print('regress')
            


def create_reg_dataset_from_files(
        filepath_list, outfile_name_prefix="reg", feature_ignore_list=None,
        max_iters=VTR_MAX_ITERS, min_iters=1
):
    create_dataset_from_files(
        filepath_list, outfile_name_prefix,
        is_classification=False, feature_ignore_list=feature_ignore_list,
        target_write_dir="compiled_routing_data/regression",
        class_threshold=max_iters, min_iters=min_iters
    )


def create_class_dataset_from_files(
        filepath_list,
        outfile_name_prefix="class",
        class_threshold=VTR_MAX_ITERS,
        min_iters=1,
        feature_ignore_list=None):
    """
    Create a dataset for classification from a set of files
    :param min_iters:
    :param filepath_list:
    :param outfile_name_prefix:
    :param class_threshold:
    :param feature_ignore_list:
    :return:
    """
    create_dataset_from_files(
        filepath_list, outfile_name_prefix,
        is_classification=True, class_threshold=class_threshold,
        feature_ignore_list=feature_ignore_list,
        target_write_dir="compiled_routing_data/classification",
        min_iters=min_iters
    )

def create_dataset_from_files(
        filepath_list, outfile_name_base,
        is_classification=False, class_threshold=VTR_MAX_ITERS,
        feature_ignore_list=None, target_write_dir="compiled_routing_data", min_iters=1
):
    base_path = path.dirname(__file__)
    target_write_path_X = path.abspath(path.join(base_path,
                                                 "..",
                                                 target_write_dir,
                                                 f"{outfile_name_base}_X.csv"))
    target_write_path_y = path.abspath(path.join(base_path,
                                                 "..",
                                                 target_write_dir,
                                                 f"{outfile_name_base}_y.csv"))
    outfile_X = open(target_write_path_X, "wt")
    outfile_y = open(target_write_path_y, "wt")
    for infile_path in filepath_list:
        # print(f'infile_patcddh is {infile_path}')
        # permiss_chan_widths = get_permissible_chan_widths(infile_path=infile_path)
        # print(f'permissiible channel widths is {permiss_chan_widths}')
        target_read_path = infile_path
        # print(f'infile_path is {infile_path}')
        with open(target_read_path, 'rt') as infile:
            for line_idx, line in enumerate(infile):
                if line_idx == 0:
                    continue

                feature_tokens = line.split(",")

                # Only include permissible channel widths
                chan_width = int(feature_tokens[Idx.CHAN_WIDTH.value])
                # if chan_width not in permiss_chan_widths:
                #     print('asdf')
                #     continue

                true_completion_iter = int(feature_tokens[Idx.TRUE_ITER.value])
                # assert true_completion_iter != 0 and true_completion_iter != -1, \
                #     f"ERROR: Bad completion iter: {true_completion_iter}"
                # if not is_classification:
                #     if true_completion_iter < -1:
                #         # Only include legally routed/completed circuit routing attempts for regression
                #         continue
                #     if true_completion_iter > class_threshold:
                #         # Only perform regression on routes within the classification limit
                #         # i.e. routes that "successfully" routed within a specified iteration tolerance
                #         continue
                # # Only include iterations prior to the max iter threshold
                # current_iter = int(feature_tokens[Idx.CURR_ITER.value])
                # if current_iter >= class_threshold:
                #     continue
                # # Ony include routes that finish at or after the specified minimum
                # if 0 < true_completion_iter < min_iters:
                #     continue

                # For each datapoint/row, we need to convert:
                # 1) VPR's routing iteration prediction
                # 2) The true iteration of completion value
                # To class values depending on the classification threshold
                vtr_prediction_absolute, vtr_predicts_convergence, vtr_prediction_class = handle_vtr_na(
                    feature_tokens=feature_tokens, class_threshold=class_threshold, is_classification=is_classification
                )

                if is_classification:
                    if true_completion_iter < -1:
                        true_completion_class = 0
                    elif 0 < true_completion_iter <= class_threshold:
                        true_completion_class = 1
                    elif true_completion_iter > class_threshold:
                        true_completion_class = 0
                    else:
                        true_completion_class = 0
                        
                        # print('error')
                        # exit(f"Bad completion iteration: {true_completion_iter}")

                if is_classification:
                    label_tokens = [str(true_completion_class), str(vtr_prediction_class) + '\n']
                else:
                    # Regression - convert completion iter to # iters remaining from current iter
                    # This is done on the intuition that it will create more varied labels and reduce likelihood
                    # of some model types overfitting on high-frequency labels.
                    current_iter = int(feature_tokens[Idx.CURR_ITER.value])
                    true_iters_remaining = true_completion_iter - current_iter
                    vtr_pred_iters_remaining = vtr_prediction_absolute - current_iter
                    label_tokens = [str(true_iters_remaining), str(vtr_pred_iters_remaining) + '\n']
                # Update VTR absolute prediction to be valid data
                feature_tokens[Idx.VTR_ITER_PRED.value] = str(vtr_prediction_absolute)
                # Add feature for whether VTR predicts routing convergence
                feature_tokens.append(str(vtr_predicts_convergence))

                # Remove ignored features
                # First need to sort ignore indices in descending order
                # Ascending order would lead to mistakes. E.g. [1, 3]
                # Would delete index 1 but then the data at index 3 would become index 2
                feature_ignore_list.sort(reverse=True)
                for deletion_idx in feature_ignore_list:
                    del feature_tokens[deletion_idx]

                # Remove newlines/space from all feature tokens
                for token_idx, token in enumerate(feature_tokens):
                    feature_tokens[token_idx] = token.strip()
                # Add newline to last feature token
                last_token = feature_tokens[-1]
                if '\n' not in last_token:
                    last_token = last_token + '\n'
                else:
                    # Error in stripping feature tokens
                    exit("ERROR: Feature tokens not stripped properly in dataset_compiler, create_dataset_from_files()!")
                feature_tokens[-1] = last_token

                feature_outline = ','.join(feature_tokens)
                label_outline = ','.join(label_tokens)
                outfile_X.write(feature_outline)
                outfile_y.write(label_outline)
    outfile_X.close()
    outfile_y.close()


def validate_compiled_dataset(is_classification=False, target_prefix=""):
    # TODO: Change so that train/test data are validated independently
    #   so that one can be turned off
    if target_prefix == "":
        exit("ERROR: Must supply a prefix to validate_compiled_dataset()!")
    is_correct_dataset = True  # Are the data correct? (within limits of correctness verification)
    is_valid_dataset = True  # Are the dataset files valid? I.e. non-empty
    # Dataset can be correct without being valid if all the data lines are
    # valid but not organized correctly.
    found_file_to_validate = False

    # Get relative path to raw data directory
    base_path = path.dirname(__file__)
    if is_classification:
        target_dir = "classification"
    else:
        target_dir = "regression"
    compiled_data_dir_path = path.abspath(path.join(base_path, "..", "compiled_routing_data", target_dir))

    for filename in os.listdir(compiled_data_dir_path):
        # Check that the file matches the target naming convention
        if not filename.startswith(target_prefix + "_") or not filename.endswith(".csv"):
            continue

        print(f"Validating {filename}")
        found_file_to_validate = True
        target_path = path.abspath(
            path.join(
                compiled_data_dir_path,
                filename
            )
        )
        with open(target_path, 'rt') as infile:
            line_count = 0
            for line_idx, line in enumerate(infile):
                tokens = line.split(',')
                for token in tokens:
                    token = token.strip()
                    if token == "True" or token == "False":
                        continue
                    try:
                        token_value = float(token)
                        # Check for the existence of nan and infinity in the data
                        if math.isnan(token_value):
                            is_valid_dataset = False
                            is_correct_dataset = False
                            print(f"NaN on line {line_idx}")
                        if math.isinf(token_value):
                            is_valid_dataset = False
                            is_correct_dataset = False
                            print(f"Inf on line {line_idx}")
                    except ValueError as e:
                        is_valid_dataset = False
                        is_correct_dataset = False
                        print(e)
                        print(tokens)
                if len(tokens) > 0:
                    line_count += 1
            if line_count == 0:
                is_valid_dataset = False

    if not found_file_to_validate:
        is_valid_dataset = False
        is_correct_dataset = False

    return is_valid_dataset, is_correct_dataset



def handle_vtr_na(feature_tokens, class_threshold=VTR_MAX_ITERS, is_classification=True):
    vtr_prediction_absolute = feature_tokens[Idx.VTR_ITER_PRED.value]

    vtr_prediction_class = -1  # Default to this for regression as an error check

    # Add binary feature for whether VTR predicts routing attempt would eventually occur
    # This is necessary for when VTR predicts "inf" or when VTR predicts convergence in a past
    # iteration (i.e. does not actually predict routing convergence)
    vtr_predicts_convergence = None  # Does VTR predict the routing attempt would eventually
    if vtr_prediction_absolute == "N/A":
        # Overwrite original data from Non-Applicable to Not a Number
        feature_tokens[Idx.VTR_ITER_PRED.value] = str(math.nan)
        vtr_prediction_absolute = VTR_NA_VALUE
        vtr_predicts_convergence = 1  # Same comment as below
        if is_classification:
            vtr_prediction_class = 1  # N/A basically tells the user to "Keep routing", same as "Is routable."
    elif vtr_prediction_absolute == "inf":
        vtr_prediction_absolute = VTR_INF_INTERPRETATION
        vtr_predicts_convergence = 0
        if is_classification:
            vtr_prediction_class = 0
    else:
        # Prediction is an integer
        vtr_prediction_absolute = int(vtr_prediction_absolute)

        # We need to handle cases where vtr predicts a past iteration
        # This happens when the routing resource overuse slope is locally positive in a difficult route
        current_iter = int(feature_tokens[Idx.CURR_ITER.value])
        if vtr_prediction_absolute <= current_iter:
            vtr_prediction_absolute = VTR_INF_INTERPRETATION  # Really, VTR is predicting infinity
            vtr_predicts_convergence = 0  # Technically vtr is predicting convergence, but practically
            # and logically this is not happening since the predicted convergence is in the past.
            # What we truly care about is if vtr predicts future convergence.
        else:
            vtr_predicts_convergence = 1
        if is_classification:
            if vtr_prediction_absolute > class_threshold or vtr_prediction_absolute == 0:
                vtr_prediction_class = 0
            else:
                vtr_prediction_class = 1
        else:
            pass

    assert vtr_prediction_absolute >= 0, f"ERROR: Bad vtr prediction: {vtr_prediction_absolute}"

    return vtr_prediction_absolute, vtr_predicts_convergence, vtr_prediction_class


def get_permissible_chan_widths(
        infile_path,
        max_above_mcw=2, max_below_mcw=2,
        max_iters=VTR_MAX_ITERS,
) -> list:
    """
    For a given processed routing data file, looks at the routing attempts in the file
    and determines the channel widths that are permissible to be used based on the specified
    maximum number of channel widths above and below the minimum channel width to include.
    :param infile_path:
    :param max_iters:
    :param max_above_mcw:  The ma
    :param max_below_mcw:
    :return: list
    """
    permiss_chan_widths = []
    route_completion_data = {}
    with open(infile_path, 'rt') as infile:
        old_line = None
        routing_fingerprint = None
        routing_attempt_length = 0
        for line_idx, line in enumerate(infile):
            if line_idx == 0:
                # Skip header
                continue

            new_routing_attempt = False
            if line_idx == 1:
                # This is the first data line of the file
                # Initialize variables

                # Identify a routing attempt by its fingerprint
                routing_fingerprint = get_route_fingerprint_from_line(line)
                routing_attempt_length = 1
            else:
                # Check for routing attempt change
                new_line_fingerprint = get_route_fingerprint_from_line(line)
                for i in range(len(routing_fingerprint)):
                    if routing_fingerprint[i] != new_line_fingerprint[i]:
                        # This line is from a new routing attempt
                        new_routing_attempt = True

                if new_routing_attempt:
                    old_tokens = old_line.split(',')
                    old_completion_iter = int(old_tokens[Idx.TRUE_ITER.value].strip())
                    old_channel_width = int(old_tokens[Idx.CHAN_WIDTH.value].strip())
                    if abs(old_completion_iter) <= max_iters:
                        assert abs(old_completion_iter) - 1 == routing_attempt_length, \
                            f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
                    else:
                        assert max_iters - 1 == routing_attempt_length, \
                            f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
                    # Record number of iters, linearity, and VTR mae
                    route_completion_data[old_channel_width] = old_completion_iter

                    # Reset for new routing attempt
                    routing_fingerprint = get_route_fingerprint_from_line(line)
                    routing_attempt_length = 1
                else:
                    routing_attempt_length += 1
            old_line = line
        # Handle case of last routing attempt in file
        old_tokens = old_line.split(',')
        
        old_completion_iter = int(old_tokens[Idx.TRUE_ITER.value].strip())
        old_channel_width = int(old_tokens[Idx.CHAN_WIDTH.value].strip())
        if abs(old_completion_iter) <= max_iters:
            assert abs(old_completion_iter) - 1 == routing_attempt_length, \
                f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
        else:
            assert max_iters - 1 == routing_attempt_length, \
                f"Bad data line {line_idx}: {old_completion_iter - 1} == {routing_attempt_length}"
        # Record number of iters, linearity, and VTR mae
        route_completion_data[old_channel_width] = old_completion_iter

    # Find minimum channel width and corresponding completion iteration at that channel width
    min_width_iters = (2048, -1)  # (min chan width, mcw completion iter)
    for chan_width, completion_iter in route_completion_data.items():
        if -2 < completion_iter < 1:
            exit(f"ERROR: Bad route completion iter detected!: {completion_iter}")
        if -11 < completion_iter <= -2 or 2 <= completion_iter < 11:
            pass
            #warn(f"WARNING: Strange route completion iter detected!: {completion_iter}")
        if completion_iter < -1 or completion_iter > max_iters:
            continue  # Unroutable
        best_width, best_completion_iter = min_width_iters
        if chan_width < best_width:
            min_width_iters = (chan_width, completion_iter)

    # Count the number of route attempts below and above the minimum channel width per circuit-placer combo
    BELOW_COUNT_IDX = 0
    ABOVE_COUNT_U_IDX = 0
    ABOVE_COUNT_R_IDX = 0
    completion_type_counts = [0, 0, 0]  # (unroutable below mcw, unroutable above mcw, routable)
    for chan_width, completion_iter in route_completion_data.items():
        min_chan_width, completion_iter_min_width = min_width_iters
        if chan_width < min_chan_width:
            completion_type_counts[BELOW_COUNT_IDX] += 1
        if chan_width > min_chan_width:
            if completion_iter < -1 or completion_iter > max_iters:
                completion_type_counts[ABOVE_COUNT_U_IDX] += 1
            elif completion_iter > 0:
                completion_type_counts[ABOVE_COUNT_R_IDX] += 1
            else:
                exit(f"ERROR: Bad completion iter: {completion_iter}")

    below_count, above_count_u, above_count_r = completion_type_counts
    min_chan_width, completion_iter = min_width_iters
    if min_chan_width == 2048:
        warn(f"No successful routes in {infile_path}")
    #print(f"{infile_path}, {min_chan_width}, {below_count}, {above_count_u}, {above_count_r}")

    # Find the channel width values that will be compiled into a dataset
    permiss_chan_widths.append(min_chan_width)
    count_above_mcw = 0
    count_below_mcw = 0
    chan_widths_to_search = list(route_completion_data.keys())
    # First start by finding the channel widths above the minimum channel width
    chan_widths_to_search.sort(reverse=False)  # Must be in ascending order for
    # routable chan width counting logic to be valid
    last_search_chan_width = 0
    for search_chan_width in chan_widths_to_search:
        assert search_chan_width > last_search_chan_width  # Confirm ascending order

        if search_chan_width == min_chan_width:
            continue
        elif search_chan_width > min_chan_width:
            assert search_chan_width not in permiss_chan_widths, \
                f"ERROR: chan width {search_chan_width} already in {permiss_chan_widths}"
            completion_iter = route_completion_data[search_chan_width]
            if completion_iter < -1 or completion_iter > max_iters:
                # Allow any unroutables above the minimum channel width
                # These routing attempts are always interesting
                # Don't add them to the count for routable chan widths above the mcw
                pass
                permiss_chan_widths.append(search_chan_width)
            elif completion_iter > 1:
                if count_above_mcw < max_above_mcw:
                    permiss_chan_widths.append(search_chan_width)
                    count_above_mcw += 1
            else:
                exit(f"ERROR: encountered bad completion iter: '{completion_iter}'")
        else:
            pass
        last_search_chan_width = search_chan_width
    # Second, now find the channel widths to include in compiled data that are below minimum channel width
    chan_widths_to_search.sort(reverse=True)  # Must be in descending order for unroutable chan width
    # counting logic to be valid
    last_search_chan_width = 2048
    for search_chan_width in chan_widths_to_search:
        assert search_chan_width < last_search_chan_width  # Confirm descending order
        if search_chan_width == min_chan_width:
            continue
        elif search_chan_width < min_chan_width:
            assert search_chan_width not in permiss_chan_widths, \
                f"ERROR: chan width {search_chan_width} already in {permiss_chan_widths}"
            completion_iter = route_completion_data[search_chan_width]
            assert completion_iter < -1 or completion_iter > max_iters, \
                f"ERROR: Encountered 'unroutable' routing attempt with bad completion iter: {completion_iter}"
            if count_below_mcw < max_below_mcw:
                permiss_chan_widths.append(search_chan_width)
                count_below_mcw += 1
        last_search_chan_width = search_chan_width
    cant_be_further_routed = [
        ("MMM", "0", "84"),
        ("MMM", "3", "84"),
        ("Reed_Solomon", "0", "84"),
        ("Reed_Solomon", "1", "84"),
        ("Reed_Solomon", "2", "84"),
        ("Reed_Solomon", "2", "82"),
        ("Reed_Solomon", "2", "80"),
        ("Reed_Solomon", "2", "78"),
        ("Reed_Solomon", "4", "84"),
        ("Reed_Solomon", "4", "82"),
        ("Reed_Solomon", "4", "80"),
        ("Reed_Solomon", "4", "78"),
        ("fir_cascade", "0", "84"),
        ("fir_cascade", "0", "82"),
        ("fir_cascade", "0", "80"),
        ("fir_cascade", "0", "78"),
        ("fir_cascade", "1", "84"),
        ("fir_cascade", "1", "82"),
        ("fir_cascade", "1", "80"),
        ("fir_cascade", "1", "78"),
        ("fir_cascade", "2", "84"),
        ("fir_cascade", "2", "82"),
        ("fir_cascade", "2", "80"),
        ("fir_cascade", "2", "78"),
        ("fir_cascade", "3", "84"),
        ("fir_cascade", "3", "82"),
        ("fir_cascade", "3", "80"),
        ("fir_cascade", "3", "78"),
        ("fir_cascade", "4", "84"),
        ("fir_cascade", "4", "82"),
        ("fir_cascade", "4", "80"),
        ("fir_cascade", "4", "78"),
        ("radar20", "0", "84"),
        ("radar20", "0", "82"),
        ("radar20", "0", "80"),
        ("radar20", "0", "78"),
        ("radar20", "1", "84"),
        ("radar20", "1", "82"),
        ("radar20", "1", "80"),
        ("radar20", "1", "78"),
        ("radar20", "2", "84"),
        ("radar20", "2", "82"),
        ("radar20", "2", "80"),
        ("radar20", "2", "78"),
        ("radar20", "3", "84"),
        ("radar20", "3", "82"),
        ("radar20", "3", "80"),
        ("radar20", "3", "78"),
        ("radar20", "4", "84"),
        ("radar20", "4", "82"),
        ("radar20", "4", "80"),
        ("radar20", "4", "78"),
        ("ucsb_152_tap_fir", "0", "78"),
        ("ucsb_152_tap_fir", "3", "84"),
        ("ucsb_152_tap_fir", "4", "84")
    ]
    if count_below_mcw < max_below_mcw:
        output_warning = True
        for circuit_name, seed, _ in cant_be_further_routed:
            if f"{circuit_name}_{seed}" in infile_path:
                output_warning = False
        if output_warning:
            warn(f"Not enough unroutable attempts in {infile_path}. Requested {max_below_mcw}, counted {count_below_mcw}")
    if count_above_mcw < max_above_mcw:
        warn(f"Not enough routable attempts in {infile_path}. Requested {max_above_mcw}, counted {count_above_mcw}")
    #print(permiss_chan_widths)
    return permiss_chan_widths


if __name__ == "__main__":
    compile_dataset(
                    is_classification=True,
                    test_circuit_names=['sparcT1_core_1_data'],
                    compile_test=True,
                    test_data_max_iters=VTR_MAX_ITERS,
                    test_data_min_iters=1
                )